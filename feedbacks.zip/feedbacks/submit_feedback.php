<?php
include "db.php";

// Get form data
$name = $_POST['name'];
$email = $_POST['email'];
$rating = $_POST['rating'];
$message = $_POST['message'];

// Handle file upload
$attachment = "";
if (isset($_FILES['attachment']) && $_FILES['attachment']['error'] == 0) {
    $upload_dir = "uploads/";
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0777, true); // create folder if not exists
    }
    $attachment = $upload_dir . basename($_FILES['attachment']['name']);
    move_uploaded_file($_FILES['attachment']['tmp_name'], $attachment);
}

// Insert into DB
$sql = "INSERT INTO feedbacks (name, email, rating, message, attachment)
        VALUES (?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssiss", $name, $email, $rating, $message, $attachment);

if ($stmt->execute()) {
    echo "✅ Feedback submitted successfully!";
} else {
    echo "❌ Error: " . $conn->error;
}
?>
