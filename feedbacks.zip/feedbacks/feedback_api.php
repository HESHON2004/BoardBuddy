<?php
header("Content-Type: application/json");
$host = "localhost";
$user = "root"; // your MySQL username
$pass = "";     // your MySQL password if any
$dbname = "boardbuddy"; // your database name

$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    die(json_encode(["error" => "DB connection failed"]));
}

// Handle request method
$method = $_SERVER['REQUEST_METHOD'];

if ($method === "GET") {
    $result = $conn->query("SELECT * FROM feedbacks ORDER BY created_at DESC");
    $feedbacks = [];
    while ($row = $result->fetch_assoc()) {
        $feedbacks[] = $row;
    }
    echo json_encode($feedbacks);
}

elseif ($method === "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'] ?? null;
    $rating = $_POST['rating'];
    $message = $_POST['message'];
    
    $attachment = null;
    if (!empty($_FILES['attachment']['name'])) {
        $uploadDir = "uploads/";
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }
        $attachment = time() . "_" . basename($_FILES['attachment']['name']);
        move_uploaded_file($_FILES['attachment']['tmp_name'], $uploadDir . $attachment);
    }

    $stmt = $conn->prepare("INSERT INTO feedbacks (name,email,rating,message,attachment) VALUES (?,?,?,?,?)");
    $stmt->bind_param("ssiss", $name, $email, $rating, $message, $attachment);
    $stmt->execute();
    echo json_encode(["success" => true]);
}

elseif ($method === "DELETE") {
    parse_str(file_get_contents("php://input"), $data);
    $id = $data["id"];
    $stmt = $conn->prepare("DELETE FROM feedbacks WHERE id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    echo json_encode(["success" => true]);
}

elseif ($method === "PUT") {
    parse_str(file_get_contents("php://input"), $data);
    $id = $data["id"];
    $name = $data["name"];
    $email = $data["email"];
    $rating = $data["rating"];
    $message = $data["message"];

    $stmt = $conn->prepare("UPDATE feedbacks SET name=?, email=?, rating=?, message=? WHERE id=?");
    $stmt->bind_param("ssisi", $name, $email, $rating, $message, $id);
    $stmt->execute();
    echo json_encode(["success" => true]);
}

$conn->close();
?>
