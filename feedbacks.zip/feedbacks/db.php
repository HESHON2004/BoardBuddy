<?php
$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "boardbuddy";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("❌ Connection failed: " . $conn->connect_error);
}

// ✅ REMOVE this line
// else { echo "✅ Database connected successfully!"; }
?>
