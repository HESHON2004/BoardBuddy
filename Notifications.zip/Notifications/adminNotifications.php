<?php
session_start();
include 'db.php';

// Admin check
if (!isset($_SESSION['user_id']) || ($_SESSION['user_role'] ?? '') !== 'Admin') {
    header("Location: signin.php");
    exit;
}

// Handle sending notification via AJAX
if (isset($_POST['ajaxSend'])) {
    $title = $conn->real_escape_string($_POST['title']);
    $message = $conn->real_escape_string($_POST['message']);
    $insertSql = "INSERT INTO notifications (title, message, type) VALUES ('$title', '$message', 'system')";
    if ($conn->query($insertSql)) {
        echo json_encode(['success'=>true,'message'=>'Notification sent successfully']);
    } else {
        echo json_encode(['success'=>false,'message'=>'Failed to send notification']);
    }
    exit;
}

// Handle deletion via AJAX
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['deleteNotificationId'])) {
    $id = intval($_POST['deleteNotificationId']);
    $check = mysqli_query($conn, "SELECT user_id, type FROM notifications WHERE id=$id");
    $row = mysqli_fetch_assoc($check);
    if ($row && $row['type'] === 'system' && $row['user_id'] === NULL) {
        mysqli_query($conn, "DELETE FROM notifications WHERE id=$id");
        echo json_encode(['success'=>true, 'message'=>'Notification deleted successfully']);
    } else {
        echo json_encode(['success'=>false,'message'=>'Cannot delete this notification']);
    }
    exit;
}

// Handle edit via AJAX
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['editNotificationId'])) {
    $id = intval($_POST['editNotificationId']);
    $title = $conn->real_escape_string($_POST['title']);
    $message = $conn->real_escape_string($_POST['message']);

    // Check if notification is editable
    $check = mysqli_query($conn, "SELECT user_id, type FROM notifications WHERE id=$id");
    $row = mysqli_fetch_assoc($check);

    if ($row && $row['type'] === 'system' && $row['user_id'] === NULL) {
        // Actually update the notification
        $update = mysqli_query($conn, "UPDATE notifications 
                                       SET title='$title', message='$message', created_at=NOW() 
                                       WHERE id=$id");
        if ($update) {
            // Fetch updated row from DB
            $res = mysqli_query($conn, "SELECT title, message, created_at FROM notifications WHERE id=$id");
            $updatedRow = mysqli_fetch_assoc($res);
            echo json_encode([
                'success' => true,
                'message' => 'Notification updated successfully',
                'notification' => [
                    'title' => $updatedRow['title'],
                    'message' => $updatedRow['message'],
                    'created_at' => date('M d, Y H:i', strtotime($updatedRow['created_at']))
                ]
            ]);
        } else {
            echo json_encode(['success'=>false,'message'=>'Failed to update notification']);
        }
    } else {
        echo json_encode(['success'=>false,'message'=>'Cannot edit this notification']);
    }
    exit;
}

// Pagination
$limit = 20;
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? intval($_GET['page']) : 1;
$offset = ($page - 1) * $limit;

// Filters
$typeFilter = $_GET['type'] ?? '';

// Base query
$sql = "SELECT * FROM notifications WHERE 1=1";
if ($typeFilter) {
    $typeFilterEsc = mysqli_real_escape_string($conn, $typeFilter);
    $sql .= " AND type='$typeFilterEsc'";
}

// Count total for pagination
$countSql = str_replace("SELECT *", "SELECT COUNT(*) as total", $sql);
$totalResult = mysqli_query($conn, $countSql);
$totalRecords = $totalResult ? mysqli_fetch_assoc($totalResult)['total'] : 0;
$totalPages = ceil($totalRecords / $limit);

// Add ordering and limit
$sql .= " ORDER BY created_at DESC LIMIT $limit OFFSET $offset";
$res = mysqli_query($conn, $sql);
$notifications = [];
while ($row = mysqli_fetch_assoc($res)) $notifications[] = $row;

mysqli_close($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Admin Notifications</title>
<link rel="stylesheet" href="styles/shared.css">
<style>
.header h1 { font-size:28px; font-weight:600; }
.header p { color:#666; margin-top:5px; margin-bottom:25px; }
.page-section { background:white; padding:20px; border-radius:12px; margin-bottom:25px; box-shadow:0 2px 10px rgba(0,0,0,0.05); }

.form-group { margin-bottom:15px; }
.form-group label { display:block; margin-bottom:6px; font-weight:500; }
.form-group input, .form-group textarea { width:100%; padding:8px 10px; border-radius:6px; border:1px solid #ddd; }
button.send-btn { background:#2563eb; color:white; padding:10px 18px; border-radius:6px; border:none; cursor:pointer; transition:0.2s; }
button.send-btn:hover { background:#1e40af; }

.success-msg { background:#10b981; color:white; padding:12px 20px; border-radius:8px; margin-bottom:20px; text-align:center; }
.error-msg { background:#dc2626; color:white; padding:12px 20px; border-radius:8px; margin-bottom:20px; text-align:center; }

table { width:100%; border-collapse: collapse; background:white; border-radius:12px; overflow:hidden; box-shadow:0 2px 10px rgba(0,0,0,0.05); }
th, td { padding:14px 16px; text-align:left; border-bottom:1px solid #f1f1f1; }
th { background:#f9fafb; font-weight:600; }
tr:hover td { background:#f9fafb; }

.edit-btn {
    background:#f97316; /* orange */
    color:white;
    padding:5px 10px;
    border:none;
    border-radius:6px;
    cursor:pointer;
    margin-left:5px;
}
.edit-btn:hover {
    background:#c2410c;
}

.save-btn {
    background:#16a34a; /* green */
    color:white;
    padding:5px 10px;
    border:none;
    border-radius:6px;
    cursor:pointer;
    margin-left:5px;
}
.save-btn:hover {
    background:#15803d;
}

.delete-btn {
    background:#dc2626; /* red */
    color:white;
    padding:5px 10px;
    border:none;
    border-radius:6px;
    cursor:pointer;
}
.delete-btn:hover {
    background:#b91c1c;
}

/* Auto-expand textarea */
textarea.auto-expand {
    width:95%;
    min-height:50px;
    resize:none;
    overflow:hidden;
}
.pagination { margin-top:20px; text-align:center; }
.pagination a { display:inline-block; margin:0 4px; padding:6px 12px; border-radius:6px; text-decoration:none; background:#f1f5f9; color:#2563eb; font-weight:500; }
.pagination a.active { background:#2563eb; color:white; }
.pagination a:hover { background:#93c5fd; color:white; }
/* Dynamic messages */
.dynamic-msg {
    padding:12px 20px;
    border-radius:8px;
    margin-bottom:20px;
    text-align:center;
}
.dynamic-msg.success-msg { background:#10b981; color:white; }
.dynamic-msg.error-msg { background:#dc2626; color:white; }

</style>
</head>
<body>
<div class="container-main">
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="logo">
            <h2>ADMIN</h2>
            <p style="color:#94a3b8; font-size:14px; margin-top:10px;">
                Welcome, <?= htmlspecialchars($_SESSION['user_name']) ?>
            </p>
        </div>
        <ul class="nav-menu">
            <li class="nav-item" onclick="location.href='adminDash.php'">Dashboard</li>
            <li class="nav-item" onclick="location.href='adminUser.php'">User Management</li>
            <li class="nav-item" onclick="location.href='allActivities.php'">All Activities</li>
            <li class="nav-item" onclick="location.href='adminReports.php'">Reports</li>
            <li class="nav-item active" onclick="location.href='adminNotifications.php'">Notifications</li>
            <li class="nav-item">Payments</li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="header">
            <h1>Admin Notifications</h1>
            <p>Total Notifications: <?= $totalRecords ?></p>

            <!-- Message container appears here -->
            <div id="dynamicMsgContainer"></div>
        </div>

        <!-- Send Notification Section -->
        <div class="page-section" id="notificationSection">
            <h3>Send Notification to All Users</h3>
            <form id="sendNotificationForm">
                <div class="form-group">
                    <label>Title</label>
                    <input type="text" name="title" required>
                </div>
                <div class="form-group">
                    <label>Message</label>
                    <textarea name="message" rows="4" required></textarea>
                </div>
                <button type="submit" class="send-btn">Send</button>
            </form>
        </div>

        <!-- Edit Notification Modal -->
        <div id="editModal" style="display:none; position:fixed; top:0; left:0;width:100%;height:100%;background:rgba(0,0,0,0.5);align-items:center;justify-content:center; z-index:9999;">
            <div style="background:white; padding:20px; border-radius:10px; width:400px; max-width:90%; position:relative;">
                <h3>Edit Notification</h3>
                <div class="form-group">
                    <label>Title</label>
                    <input type="text" id="editTitle" style="width:100%; padding:8px; border-radius:6px; border:1px solid #ddd;">
                </div>
                <div class="form-group">
                    <label>Message</label>
                    <textarea id="editMessage" rows="5" style="width:100%; padding:8px; border-radius:6px; border:1px solid #ddd;"></textarea>
                </div>
                <div style="text-align:right;">
                    <button onclick="closeModal()" style="margin-right:10px; padding:6px 12px; border-radius:6px; border:none; background:#dc2626; color:white; cursor:pointer;">Cancel</button>
                    <button id="saveEditBtn" style="padding:6px 12px; border-radius:6px; border:none; background:#16a34a; color:white; cursor:pointer;">Save</button>
                </div>
            </div>
        </div>


        <!-- Notifications Table -->
        <div class="page-section">
            <table>
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Message</th>
                        <th>Type</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php if($notifications): ?>
                    <?php foreach($notifications as $n): ?>
                        <tr>
                            <td><?= htmlspecialchars($n['title']) ?></td>
                            <td><?= htmlspecialchars($n['message']) ?></td>
                            <td><?= htmlspecialchars($n['type']) ?></td>
                            <td><?= date('M d, Y H:i', strtotime($n['created_at'])) ?></td>
                            <td>
                                <?php if($n['type']==='system' && $n['user_id']===NULL): ?>
                                    <button class="delete-btn" onclick="deleteNotification(<?= $n['id'] ?>)">Delete</button>
                                    <button class="edit-btn" data-id="<?= $n['id'] ?>" 
                                            data-title="<?= htmlspecialchars($n['title'], ENT_QUOTES) ?>" 
                                            data-message="<?= htmlspecialchars($n['message'], ENT_QUOTES) ?>"
                                            onclick="openEditModal(this)">
                                        Edit
                                    </button>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="5" style="text-align:center;color:#666;padding:20px;">No notifications found.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>

            <!-- Pagination -->
            <?php if($totalPages > 1): ?>
                <div class="pagination">
                    <?php for($i=1;$i<=$totalPages;$i++): ?>
                        <a href="?page=<?= $i ?>" class="<?= $i==$page?'active':'' ?>"><?= $i ?></a>
                    <?php endfor; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
const form = document.getElementById('sendNotificationForm');
const msgContainer = document.getElementById('dynamicMsgContainer');

form.addEventListener('submit', function(e){
    e.preventDefault();
    const formData = new FormData(form);
    formData.append('ajaxSend', 1);

    fetch('', { method:'POST', body: formData })
    .then(res => res.json())
    .then(data => {
        if(data.success){
            showMessage(data.message, 'success');
            setTimeout(()=>{ location.reload(); }, 1200);
        } else {
            showMessage(data.message || 'Failed to send notification', 'error');
        }
    });
});

function deleteNotification(id){
    if(confirm('Are you sure you want to delete this notification?')){
        fetch('',{
            method:'POST',
            headers: {'Content-Type':'application/x-www-form-urlencoded'},
            body:'deleteNotificationId='+id
        })
        .then(res=>res.json())
        .then(data=>{
            if(data.success){
                showMessage(data.message, 'error'); // red for delete
                setTimeout(()=>{ location.reload(); }, 1200);
            }
            else{ showMessage(data.message || 'Failed to delete notification', 'error'); }
        });
    }
}

function showMessage(text, type){
    // Remove previous message
    msgContainer.innerHTML = '';

    const msgDiv = document.createElement('div');
    msgDiv.className = 'dynamic-msg ' + (type==='success' ? 'success-msg' : 'error-msg');
    msgDiv.innerText = text;

    msgContainer.appendChild(msgDiv);

    // Auto-hide after 5 seconds
    setTimeout(()=>{ msgDiv.remove(); }, 5000);
}

let currentEditId = null;
function openEditModal(btn){
    currentEditId = btn.dataset.id;
    document.getElementById('editTitle').value = btn.dataset.title;
    document.getElementById('editMessage').value = btn.dataset.message;
    document.getElementById('editModal').style.display = 'flex';
}

function closeModal(){
    document.getElementById('editModal').style.display = 'none';
    currentEditId = null;
}

document.getElementById('saveEditBtn').addEventListener('click', function(){
    if(!currentEditId) return;
    const title = document.getElementById('editTitle').value;
    const message = document.getElementById('editMessage').value;

    const formData = new URLSearchParams();
    formData.append('editNotificationId', currentEditId);
    formData.append('title', title);
    formData.append('message', message);

    fetch('', {
        method: 'POST',
        headers: {'Content-Type':'application/x-www-form-urlencoded'},
        body: formData.toString()
    })
    .then(res => res.json())
    .then(data => {
        if(data.success){
            showMessage(data.message, 'success');
            // Update table row
            const row = document.querySelector(`button[data-id='${currentEditId}']`).closest('tr');
            row.cells[0].innerText = data.notification.title;
            row.cells[1].innerText = data.notification.message;
            row.cells[3].innerText = data.notification.created_at;

            // Update button data for next edit
            const btn = row.querySelector('button.edit-btn');
            btn.dataset.title = data.notification.title;
            btn.dataset.message = data.notification.message;
            closeModal();
        } else {
            showMessage(data.message || 'Failed to update notification', 'error');
        }
    });
});
</script>
</body>
</html>