<?php
session_start();
include '../db.php';
require '../vendor/autoload.php'; // mPDF autoload

use Mpdf\Mpdf;

// ✅ Ensure only admins can generate reports
if (!isset($_SESSION['user_id']) || ($_SESSION['user_role'] ?? '') !== 'Admin') {
  header("Location: ../signin.php");
  exit;
}

// ✅ Fetch notifications count grouped by date
$query = "SELECT DATE(created_at) AS date, COUNT(*) AS count 
          FROM notifications 
          GROUP BY DATE(created_at) 
          ORDER BY DATE(created_at) ASC";
$result = $conn->query($query);

$dates = [];
$counts = [];
$total = 0;

if ($result && $result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {
    $dates[] = $row['date'];
    $counts[] = (int)$row['count'];
    $total += $row['count'];
  }
}

// ✅ Prepare chart configuration (Line Chart)
$chartConfig = [
  'type' => 'line',
  'data' => [
    'labels' => $dates,
    'datasets' => [[
      'label' => 'Notifications Sent',
      'data' => $counts,
      'fill' => false,
      'borderColor' => '#2563eb',
      'backgroundColor' => '#2563eb',
      'tension' => 0.2
    ]]
  ],
  'options' => [
    'plugins' => [
      'legend' => [
        'display' => true,
        'position' => 'bottom'
      ]
    ],
    'scales' => [
      'x' => ['title' => ['display' => true, 'text' => 'Date']],
      'y' => ['title' => ['display' => true, 'text' => 'Count'], 'beginAtZero' => true]
    ]
  ]
];

// ✅ Chart URL (QuickChart)
$chartUrl = "https://quickchart.io/chart?c=" . urlencode(json_encode($chartConfig)) . "&width=700&height=400&format=png";

// ✅ Fetch chart as base64
$chartImage = @file_get_contents($chartUrl);
$chartBase64 = $chartImage ? 'data:image/png;base64,' . base64_encode($chartImage) : null;

// ✅ Create PDF
$mpdf = new Mpdf([
  'allow_output_buffering' => true,
  'isRemoteEnabled' => true
]);
$mpdf->SetTitle('Notifications Sent Over Time Report');

// ✅ Build HTML content
$html = '
<h1 style="text-align:center; color:#333;">Notifications Sent Over Time</h1>
<p style="text-align:center; font-size:14px; color:#666;">Generated on: '.date("Y-m-d H:i:s").'</p>
<hr style="margin:15px 0;">

<h3 style="color:#333;">Summary</h3>
<table style="width:100%; border-collapse:collapse; margin-bottom:15px; font-size:13px;">
  <tr>
    <th style="border:1px solid #ddd; padding:8px; background:#f0f0f0;">Date</th>
    <th style="border:1px solid #ddd; padding:8px; background:#f0f0f0;">Notifications Sent</th>
  </tr>';

for ($i = 0; $i < count($dates); $i++) {
  $html .= '
  <tr>
    <td style="border:1px solid #ddd; padding:8px;">'.$dates[$i].'</td>
    <td style="border:1px solid #ddd; padding:8px;">'.$counts[$i].'</td>
  </tr>';
}

$html .= '
  <tr style="font-weight:bold;">
    <td style="border:1px solid #ddd; padding:8px;">Total</td>
    <td style="border:1px solid #ddd; padding:8px;">'.$total.'</td>
  </tr>
</table>';

// Add chart
if ($chartBase64) {
  $html .= '
  <div style="text-align:center; margin-top:25px;">
    <h3 style="color:#333;">Notifications Trend Over Time</h3>
    <img src="'.$chartBase64.'" style="width:90%; max-width:700px;" />
  </div>';
} else {
  $html .= '<p style="text-align:center; color:red;">⚠️ Could not load chart. Please check your internet connection.</p>';
}

// Output PDF
$mpdf->WriteHTML($html);
$filename = 'Notifications_Over_Time_Report_'.date("Ymd_His").'.pdf';
$mpdf->Output($filename, 'D');
exit;
