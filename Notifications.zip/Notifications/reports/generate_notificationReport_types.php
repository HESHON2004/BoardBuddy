<?php
session_start();
include '../db.php';
require '../vendor/autoload.php'; // mPDF autoload

use Mpdf\Mpdf;

// ✅ Ensure only admins can generate reports
if (!isset($_SESSION['user_id']) || ($_SESSION['user_role'] ?? '') !== 'Admin') {
    header("Location: ../signin.php");
    exit;
}

// ✅ Get notification type counts
$query = "SELECT type, COUNT(*) AS count FROM notifications GROUP BY type";
$result = $conn->query($query);

$types = [];
$counts = [];
$total = 0;

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $types[] = $row['type'];
        $counts[] = (int)$row['count'];
        $total += $row['count'];
    }
}

// ✅ Calculate percentages
$percentages = [];
foreach ($counts as $count) {
    $percentages[] = $total > 0 ? round(($count / $total) * 100, 2) : 0;
}

// ✅ Prepare chart configuration
$chartConfig = [
    'type' => 'pie',
    'data' => [
        'labels' => $types,
        'datasets' => [[
            'data' => $counts,
            'backgroundColor' => ['#4CAF50', '#2196F3', '#FF9800', '#9C27B0', '#F44336', '#00BCD4'],
            'borderColor' => '#fff',
            'borderWidth' => 2
        ]]
    ],
    'options' => [
        'plugins' => [
            'legend' => [
                'position' => 'bottom',
                'labels' => [
                    'font' => ['size' => 16]
                ]
            ],
            'datalabels' => [
                'color' => '#fff',
                'font' => ['size' => 16, 'weight' => 'bold'],
                'formatter' => 'function(value, context) {
                    let sum = 0;
                    let dataArr = context.chart.data.datasets[0].data;
                    dataArr.map(data => sum += data);
                    let percentage = (value * 100 / sum).toFixed(1) + "%";
                    return percentage;
                }'
            ]
        ]
    ]
];

// ✅ Chart URL (QuickChart)
$chartUrl = "https://quickchart.io/chart?c=" . urlencode(json_encode($chartConfig)) . "&width=700&height=500&format=png&plugins=datalabels";
$chartImage = @file_get_contents($chartUrl);
$chartBase64 = $chartImage ? 'data:image/png;base64,' . base64_encode($chartImage) : null;

// ✅ Create PDF
$mpdf = new Mpdf(['allow_output_buffering' => true, 'isRemoteEnabled' => true]);
$mpdf->SetTitle('Most Frequent Notification Types Report');

// ✅ Build HTML content
$html = '
<h1 style="text-align:center; color:#333;">Most Frequent Notification Types Report</h1>
<p style="text-align:center; font-size:14px; color:#666;">Generated on: '.date("Y-m-d H:i:s").'</p>
<hr style="margin:15px 0;">

<h3 style="color:#333;">Summary</h3>
<table style="width:100%; border-collapse:collapse; margin-bottom:15px; font-size:13px;">
<tr>
<th style="border:1px solid #ddd; padding:8px; background:#f0f0f0;">Notification Type</th>
<th style="border:1px solid #ddd; padding:8px; background:#f0f0f0;">Count</th>
<th style="border:1px solid #ddd; padding:8px; background:#f0f0f0;">Percentage</th>
</tr>';

for ($i = 0; $i < count($types); $i++) {
    $html .= '
    <tr>
        <td style="border:1px solid #ddd; padding:8px;">'.$types[$i].'</td>
        <td style="border:1px solid #ddd; padding:8px;">'.$counts[$i].'</td>
        <td style="border:1px solid #ddd; padding:8px;">'.$percentages[$i].'%</td>
    </tr>';
}

$html .= '
<tr style="font-weight:bold;">
    <td style="border:1px solid #ddd; padding:8px;">Total</td>
    <td style="border:1px solid #ddd; padding:8px;">'.$total.'</td>
    <td style="border:1px solid #ddd; padding:8px;">100%</td>
</tr>
</table>';

// ✅ Add chart
if ($chartBase64) {
    $html .= '
    <div style="text-align:center; margin-top:25px;">
        <h3 style="color:#333;">Notification Types Distribution</h3>
        <img src="'.$chartBase64.'" style="width:80%; max-width:600px;" />
    </div>';
} else {
    $html .= '<p style="text-align:center; color:red;">⚠️ Could not load chart. Please check your internet connection.</p>';
}

// ✅ Output PDF
$mpdf->WriteHTML($html);
$filename = 'Notification_Types_Report_'.date("Ymd_His").'.pdf';
$mpdf->Output($filename, 'D');
exit;
