<?php
if (!function_exists('createNotification')) {
    /**
     * Create a notification
     * 
     * @param mysqli $conn       Active DB connection
     * @param int|null $userId   Target user ID (null = global)
     * @param string $title      Notification title
     * @param string $message    Notification message
     * @param string|null $link  Optional redirect link (e.g. 'property.php?id=3')
     * @param string $type       Notification type (default: 'system')
     * @return bool
     */
    function createNotification($conn, $userId, $title, $message, $link = null, $type = 'message') {
        $stmt = $conn->prepare("
            INSERT INTO notifications (user_id, title, message, link, type, is_read, created_at)
            VALUES (?, ?, ?, ?, ?, 0, NOW())
        ");
        $stmt->bind_param("issss", $userId, $title, $message, $link, $type);
        return $stmt->execute();
    }
}
?>
