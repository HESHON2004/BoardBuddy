<?php
session_start();
require_once 'config.php';
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: userManagement/signin.php");
    exit;
}

$userId = $_SESSION['user_id'];

// Filters from GET
$filterRead = $_GET['filter_read'] ?? 'all'; // all / unread / read
$filterCategory = $_GET['category'] ?? 'all'; // all / booking / payment / message / promotion
$filterDate = $_GET['date'] ?? ''; // single date

// Build WHERE conditions
$where = "WHERE (user_id = $userId OR user_id IS NULL)";

if ($filterRead === 'unread') {
    $where .= " AND is_read = 0";
} elseif ($filterRead === 'read') {
    $where .= " AND is_read = 1";
}

if ($filterCategory !== 'all') {
    // make sure it matches type in DB
    $where .= " AND type = '" . $conn->real_escape_string($filterCategory) . "'";
}

if (!empty($filterDate)) {
    $where .= " AND DATE(created_at) = '" . $conn->real_escape_string($filterDate) . "'";
}

// Fetch notifications
$query = "SELECT * FROM notifications $where ORDER BY created_at DESC";
$result = $conn->query($query);

// Mark all fetched notifications as read
$updateStmt = $conn->prepare("UPDATE notifications SET is_read = 1 WHERE (user_id = ? OR user_id IS NULL) AND is_read = 0");
$updateStmt->bind_param("i", $userId);
$updateStmt->execute();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Notifications - BoardBuddy</title>
<link rel="stylesheet" href="styles/style.css">
<link rel="stylesheet" href="styles/navigation.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
.notification-item {
    text-decoration: none;
    color: inherit;
    transition: background-color 0.2s, transform 0.1s;
    padding: 12px;
    border-radius: 8px;
    display: block;
    margin-bottom: 6px;
}
.notification-item:hover {
    transform: scale(1.02);
    background-color: #f0f8ff;
}
.notification-item.unread { border-left: 4px solid #0d6efd; background-color: #e7f1ff; }
</style>
</head>
<body>

<?php
$userRole = $_SESSION['user_role'] ?? null;
if ($userRole === 'Owner') {
    include 'navigation/ownerNav.php';
} else {
    include 'navigation/userNav.php';
}
?>

<section class="container mt-4">
    <h2>Notifications</h2>

    <!-- Filter Form -->
    <form class="row g-2 mb-3" method="GET" action="">
        <div class="col-auto">
            <select name="filter_read" class="form-select form-select-sm">
                <option value="all" <?php if($filterRead==='all') echo 'selected'; ?>>All</option>
                <option value="unread" <?php if($filterRead==='unread') echo 'selected'; ?>>Unread</option>
                <option value="read" <?php if($filterRead==='read') echo 'selected'; ?>>Read</option>
            </select>
        </div>

        <div class="col-auto">
            <select name="category" class="form-select form-select-sm">
                <option value="all" <?php if($filterCategory==='all') echo 'selected'; ?>>All Categories</option>
                <option value="booking" <?php if($filterCategory==='booking') echo 'selected'; ?>>Booking Updates</option>
                <option value="payment" <?php if($filterCategory==='payment') echo 'selected'; ?>>Payment Alerts</option>
                <option value="message" <?php if($filterCategory==='message') echo 'selected'; ?>>Messages</option>
                <option value="promotion" <?php if($filterCategory==='promotion') echo 'selected'; ?>>Promotions</option>
            </select>
        </div>

        <div class="col-auto">
            <input type="date" name="date" class="form-control form-control-sm" value="<?php echo htmlspecialchars($filterDate); ?>">
        </div>

        <div class="col-auto">
            <button type="submit" class="btn btn-primary btn-sm">Filter</button>
        </div>
    </form>

    <!-- Notifications List -->
    <?php if($result && $result->num_rows > 0): ?>
        <div class="list-group">
        <?php while($row = $result->fetch_assoc()): 
            $link = !empty($row['link']) ? $row['link'] : '#';
            $unreadClass = $row['is_read'] == 0 ? 'unread' : '';
        ?>
            <a href="<?php echo htmlspecialchars($link); ?>" 
               class="notification-item <?php echo $unreadClass; ?>">
                <strong><?php echo htmlspecialchars($row['title']); ?></strong>
                <p class="mb-1"><?php echo htmlspecialchars($row['message']); ?></p>
                <small class="text-muted float-end"><?php echo date("Y-m-d H:i", strtotime($row['created_at'])); ?></small>
            </a>
        <?php endwhile; ?>
        </div>
    <?php else: ?>
        <p>No notifications found.</p>
    <?php endif; ?>
</section>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>