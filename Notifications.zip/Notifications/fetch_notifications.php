<?php
require_once __DIR__ . '/db.php';
session_start();

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
  echo json_encode([]);
  exit;
}

$userId = $_SESSION['user_id'];

// Get last 5 notifications for this user or global
$sql = "
  SELECT id, title, message, is_read, created_at
  FROM notifications
  WHERE user_id = ? OR user_id IS NULL
  ORDER BY created_at DESC
  LIMIT 5
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();

$notifications = [];
while ($row = $result->fetch_assoc()) {
  $notifications[] = $row;
}

echo json_encode($notifications);
?>
