<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: userManagement/signin.php");
    exit;
}

// Check if user is admin
if ($_SESSION['user_role'] !== 'Admin') {
    header("Location: userManagement/signin.php");
    exit;
}

// Connect to database
$con = mysqli_connect("localhost", "root", "", "boardbuddy", 3306);
if (!$con) {
    die("Database connection failed: " . mysqli_connect_error());
}

// Fetch users from database

// Try to use last_login if available, else fallback to created_at
$query = "SELECT id, first_name, last_name, email, phone, role, status, created_at, IFNULL(last_login, created_at) AS last_login FROM users ORDER BY created_at DESC";
$result = mysqli_query($con, $query);

// Mark users inactive if they haven't logged in for 2 days
$updateStatusQuery = "
    UPDATE users 
    SET status = 'Inactive' 
    WHERE last_login < NOW() - INTERVAL 2 DAY 
      AND status != 'Inactive'
";
mysqli_query($con, $updateStatusQuery);


$users = [];
while ($row = mysqli_fetch_assoc($result)) {
    $users[] = [
        'id' => $row['id'],
        'name' => $row['first_name'] . ' ' . $row['last_name'], // keep full name
        'first_name' => $row['first_name'],
        'last_name' => $row['last_name'],
        'email' => $row['email'],
        'phone' => $row['phone'] ?? '',
        'role' => $row['role'],
        'status' => $row['status'], // use DB value directly
        'lastLogin' => date('Y-m-d H:i:s', strtotime($row['last_login'] ?? $row['created_at']))
    ];
}


mysqli_close($con);

// Handle success/error messages
$successMessage = '';
$errorMessage = '';

if (isset($_GET['success'])) {
    $successMessage = htmlspecialchars($_GET['success']);
}

if (isset($_GET['error'])) {
    $errorMessage = htmlspecialchars($_GET['error']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management - Admin Panel</title>
    <link rel="stylesheet" href="styles/admin.css">
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo">
                <h2>ADMIN</h2>
                <p style="color: #94a3b8; font-size: 14px; margin-top: 10px;">Welcome, <?php echo htmlspecialchars($_SESSION['user_name']); ?></p>
            </div>
            <ul class="nav-menu">
                <li class="nav-item" onclick="location.href='adminDash.php'"> Dashboard</li>
                <li class="nav-item active"> User Management</li>
                <li class="nav-item" onclick="location.href='allActivities.php'">All Activities</li>
                <li class="nav-item" onclick="location.href='adminReports.php'"> Reports</li>
                <li class="nav-item" onclick="location.href='adminNotifications.php'">Notifications</li>
                <li class="nav-item"> Payments</li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <?php if (!empty($successMessage)): ?>
            <div id="successMessage" style="background: #10b981; color: white; padding: 12px 20px; border-radius: 8px; margin-bottom: 20px; text-align: center; font-weight: 500;">
                ✅ <?php echo $successMessage; ?>
            </div>
            <?php endif; ?>
            
            <?php if (!empty($errorMessage)): ?>
            <div id="errorMessage" style="background: #dc2626; color: white; padding: 12px 20px; border-radius: 8px; margin-bottom: 20px; text-align: center; font-weight: 500;">
                ❌ <?php echo $errorMessage; ?>
            </div>
            <?php endif; ?>
            
            <div class="header">
                <div>
                    <h1>User Management</h1>
                    <p>Manage Users, Owners, and administrative staff</p>
                </div>
                <div style="display: flex; gap: 10px; align-items: center;">
                    <button class="add-user-btn" onclick="openAddUserModal()">+ Add New User</button>
                </div>
            </div>

            <div class="user-directory">
                <div class="directory-header" style="display: flex; justify-content: space-between; align-items: center;">
                    <div>
                        <h3 class="directory-title">User Directory</h3>
                        <p class="directory-subtitle">Search and filter system users (<span id="user-count"><?php echo count($users); ?></span> users)</p>
                    </div>
                </div>

                <div class="search-filters">
                    <div class="search-box">
                        <input type="text" id="searchInput" placeholder="Search by name or email..." onkeyup="filterUsers()">
                    </div>
                    <select class="filter-dropdown" id="roleFilter" onchange="filterUsers()">
                        <option value="">All Roles</option>
                        <option value="Admin">Admin</option>
                        <option value="User">User</option>
                        <option value="Owner">Owner</option>
                    </select>
                    <select class="filter-dropdown" id="statusFilter" onchange="filterUsers()">
                        <option value="">All Status</option>
                        <option value="Active">Active</option>
                        <option value="Inactive">Inactive</option>
                    </select>
                </div>

                <table class="user-table">
                    <thead>
                        <tr>
                            <th>NAME</th>
                            <th>EMAIL</th>
                            <th>PHONE</th>
                            <th>ROLE</th>
                            <th>STATUS</th>
                            <th>LAST LOGIN</th>
                            <th>ACTIONS</th>
                        </tr>
                    </thead>
                    <tbody id="userTableBody">
                        <!-- User rows will be populated by JavaScript -->
                    </tbody>
                </table>
                <div id="paginationControls" style="display:flex; justify-content:center; align-items:center; margin-top:20px;"></div>
            </div>
        </div>
    </div>

    <!-- Add/Edit User Modal -->
    <div id="userModal" class="modal">
        <div class="modal-content">
            <h2 id="modalTitle">Add New User</h2>
            <form id="userForm" action="" method="POST">
                <input type="hidden" id="userId" name="userId">
                <input type="hidden" id="formMode" name="formMode" value="add">
                <div class="form-group">
                    <label for="firstName">First Name</label>
                    <input type="text" id="firstName" name="firstName" required>
                </div>
                <div class="form-group">
                    <label for="lastName">Last Name</label>
                    <input type="text" id="lastName" name="lastName" required>
                </div>
                <div class="form-group">
                    <label for="userEmail">Email Address</label>
                    <input type="email" id="userEmail" name="email" required>
                </div>
                <div class="form-group">
                    <label for="phoneNumber">Phone Number</label>
                    <input type="tel" id="phoneNumber" name="phoneNumber" placeholder="+1234567890">
                </div>
                <div class="form-group">
                    <label for="password">Password <span id="passwordNote" style="color: #666; font-size: 12px; display: none;">(Leave blank to keep current password)</span></label>
                    <input type="password" id="password" name="password" minlength="6">
                </div>
                <div class="form-group">
                    <label for="userRole">Role</label>
                    <select id="userRole" name="role" required>
                        <option value="">Select Role</option>
                        <option value="Admin">Admin</option>
                        <option value="User">User</option>
                        <option value="Owner">Owner</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="userStatus">Status</label>
                    <select id="userStatus" name="status" required>
                        <option value="Active">Active</option>
                        <option value="Inactive">Inactive</option>
                    </select>
                </div>
                <div class="modal-actions">
                    <button type="button" class="btn-cancel" onclick="closeModal()">Cancel</button>
                    <button type="submit" class="btn-save">Save User</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Chart.js, jsPDF, html2canvas CDN -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>

    <script>
        // User data from PHP backend
        let users = <?php echo json_encode($users); ?>;

        let currentEditId = null;

        // Pagination variables
        let currentPage = 1;
        const usersPerPage = 15;

        // Initialize the page
        document.addEventListener('DOMContentLoaded', function() {
            renderUsers();
            updateUserCount();
        });

        // Render users in table
        function renderUsers(filteredUsers = users) {
            const tbody = document.getElementById('userTableBody');
            tbody.innerHTML = '';

            if (filteredUsers.length === 0) {
                tbody.innerHTML = '<tr><td colspan="7" style="text-align: center; padding: 40px; color: #666;">No users found</td></tr>';
                document.getElementById('paginationControls').innerHTML = '';
                return;
            }

            const totalPages = Math.ceil(filteredUsers.length / usersPerPage);

            // Slice users for current page
            const startIndex = (currentPage - 1) * usersPerPage;
            const paginatedUsers = filteredUsers.slice(startIndex, startIndex + usersPerPage);

            paginatedUsers.forEach(user => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td><strong>${user.name}</strong></td>
                    <td><a href="mailto:${user.email}" class="email-link">${user.email}</a></td>
                    <td>${user.phone || 'N/A'}</td>
                    <td>${user.role}</td>
                    <td><span class="status-badge ${user.status === 'Active' ? 'status-active' : 'status-inactive'}">${user.status}</span></td>
                    <td>${user.lastLogin}</td>
                    <td>
                        <div class="actions-menu">
                            <button class="actions-btn edit" onclick="editUser(${user.id})" title="Edit User">
                                <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/>
                                </svg>
                            </button>
                            <button class="actions-btn delete" onclick="deleteUser(${user.id})" title="Delete User">
                                <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/>
                                </svg>
                            </button>
                        </div>
                    </td>
                `;
                tbody.appendChild(row);
            });

            updateUserCount(filteredUsers.length);
            renderPaginationControls(totalPages, filteredUsers);
        }

        //pagination
        function renderPaginationControls(totalPages, filteredUsers) {
            const paginationDiv = document.getElementById('paginationControls');
            paginationDiv.innerHTML = '';

            if (totalPages <= 1) return;

            // Prev button
            const prevBtn = document.createElement('button');
            prevBtn.textContent = '← Prev';
            prevBtn.disabled = currentPage === 1;
            prevBtn.onclick = () => {
                currentPage--;
                renderUsers(filteredUsers);
            };
            paginationDiv.appendChild(prevBtn);

            // Numbered pages (show up to 5 pages at a time)
            const maxVisible = 5;
            let startPage = Math.max(1, currentPage - Math.floor(maxVisible / 2));
            let endPage = Math.min(totalPages, startPage + maxVisible - 1);

            // Adjust start if at the end
            if (endPage - startPage < maxVisible - 1) {
                startPage = Math.max(1, endPage - maxVisible + 1);
            }

            for (let i = startPage; i <= endPage; i++) {
                const pageBtn = document.createElement('button');
                pageBtn.textContent = i;
                if (i === currentPage) {
                    pageBtn.style.background = '#3b5998'; // slightly lighter blue
                    pageBtn.style.color = '#fff';
                    pageBtn.style.fontWeight = '600';
                    pageBtn.style.opacity = '0.85';
                    pageBtn.style.cursor = 'default';
                } else {
                    pageBtn.onclick = () => {
                        currentPage = i;
                        renderUsers(filteredUsers);
                    };
                }
                paginationDiv.appendChild(pageBtn);
            }

            // Next button
            const nextBtn = document.createElement('button');
            nextBtn.textContent = 'Next →';
            nextBtn.disabled = currentPage === totalPages;
            nextBtn.onclick = () => {
                currentPage++;
                renderUsers(filteredUsers);
            };
            paginationDiv.appendChild(nextBtn);

            // Style all pagination buttons
            paginationDiv.querySelectorAll('button').forEach(btn => {
                btn.style.background = '#2563eb';
                btn.style.color = 'white';
                btn.style.border = 'none';
                btn.style.padding = '6px 12px';
                btn.style.borderRadius = '8px';
                btn.style.margin = '0 4px';
                btn.style.cursor = btn.disabled ? 'not-allowed' : 'pointer';
                btn.style.opacity = btn.disabled ? '0.6' : '1';
                btn.style.transition = 'all 0.2s';
            });

            paginationDiv.style.gap = '6px';
        }

        // Filter users
        function filterUsers() {
            currentPage = 1; // reset to first page on new filter
            const searchTerm = document.getElementById('searchInput').value.toLowerCase();
            const roleFilter = document.getElementById('roleFilter').value;
            const statusFilter = document.getElementById('statusFilter').value;

            const filtered = users.filter(user => {
                const matchesSearch = user.name.toLowerCase().includes(searchTerm) || 
                                    user.email.toLowerCase().includes(searchTerm);
                const matchesRole = !roleFilter || user.role === roleFilter;
                const matchesStatus = !statusFilter || user.status === statusFilter;

                return matchesSearch && matchesRole && matchesStatus;
            });

            renderUsers(filtered);
        }


        // Open add user modal
        function openAddUserModal() {
            document.getElementById('modalTitle').textContent = 'Add New User';
            document.getElementById('formMode').value = 'add';
            document.getElementById('userForm').reset();
            document.getElementById('userId').value = '';
            document.getElementById('firstName').value = '';
            document.getElementById('lastName').value = '';
            document.getElementById('userEmail').value = '';
            document.getElementById('phoneNumber').value = '';
            document.getElementById('password').value = '';
            document.getElementById('userRole').value = '';
            document.getElementById('userStatus').value = 'Active';
            document.getElementById('password').required = true;
            document.getElementById('passwordNote').style.display = 'none';
            currentEditId = null;
            document.getElementById('userModal').style.display = 'block';
        }

        // Edit user
        function editUser(userId) {
            const user = users.find(u => u.id == userId);
            if (user) {
                document.getElementById('modalTitle').textContent = 'Edit User';
                document.getElementById('formMode').value = 'edit';
                document.getElementById('userId').value = user.id;
                
                // Split the full name into first and last name
                const nameParts = user.name.split(' ');
                const firstName = nameParts[0] || '';
                const lastName = nameParts.slice(1).join(' ') || '';
                
                document.getElementById('firstName').value = firstName;
                document.getElementById('lastName').value = lastName;
                document.getElementById('userEmail').value = user.email;
                document.getElementById('phoneNumber').value = user.phone || '';
                document.getElementById('password').value = '';
                document.getElementById('userRole').value = user.role;
                document.getElementById('userStatus').value = user.status;
                document.getElementById('password').required = false;
                document.getElementById('passwordNote').style.display = 'inline';
                currentEditId = userId;
                document.getElementById('userModal').style.display = 'block';
            }
        }

        // Fetch users from backend and update table
        function fetchUsersAndRender() {
            fetch(window.location.href, { method: 'GET' })
                .then(response => response.text())
                .then(html => {
                    // Extract users JSON from PHP
                    const match = html.match(/let users = (.*?);/);
                    if (match && match[1]) {
                        users = JSON.parse(match[1]);
                        renderUsers();
                        updateUserCount();
                    }
                });
        }

        // Delete user
        function deleteUser(userId) {
            if (confirm('Are you sure you want to delete this user?')) {
                fetch('userManagement/delete_user_handler.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: 'userId=' + encodeURIComponent(userId)
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showSuccessMessage('User deleted successfully!');
                        fetchUsersAndRender();
                    } else {
                        alert('Failed to delete user: ' + (data.message || 'Unknown error'));
                    }
                })
                .catch(() => {
                    alert('Failed to delete user: Network error');
                });
            }
        }

        // Show success message dynamically
        function showSuccessMessage(message) {
            // Remove any existing success message
            const oldMsg = document.getElementById('successMessage');
            if (oldMsg) oldMsg.remove();
            // Create new message div
            const msgDiv = document.createElement('div');
            msgDiv.id = 'successMessage';
            msgDiv.style.background = '#10b981';
            msgDiv.style.color = 'white';
            msgDiv.style.padding = '12px 20px';
            msgDiv.style.borderRadius = '8px';
            msgDiv.style.marginBottom = '20px';
            msgDiv.style.textAlign = 'center';
            msgDiv.style.fontWeight = '500';
            msgDiv.textContent = '✅ ' + message;
            // Insert at top of main-content
            const mainContent = document.querySelector('.main-content');
            mainContent.insertBefore(msgDiv, mainContent.firstChild);
            // Auto-hide after 3 seconds
            setTimeout(() => {
                msgDiv.style.opacity = '0';
                setTimeout(() => {
                    msgDiv.remove();
                }, 500);
            }, 3000);
        }

        // Close modal
        function closeModal() {
            document.getElementById('userModal').style.display = 'none';
        }

        // Handle form submission
        document.getElementById('userForm').addEventListener('submit', function(e) {
            const formMode = document.getElementById('formMode').value;
            const form = document.getElementById('userForm');
            
            // Set the correct action based on mode
            if (formMode === 'add') {
                form.action = 'userManagement/add_user_handler.php';
            } else {
                form.action = 'userManagement/edit_user_handler.php';
            }
            
            // For add mode, password is required
            if (formMode === 'add') {
                const passwordField = document.getElementById('password');
                passwordField.required = true;
            } else {
                // For edit mode, password is optional
                const passwordField = document.getElementById('password');
                passwordField.required = false;
            }
        });

        // Update user count
        function updateUserCount(count = users.length) {
            document.getElementById('user-count').textContent = count;
        }

        // Close modal when clicking outside
        window.onclick = function(event) {
            const modal = document.getElementById('userModal');
            if (event.target === modal) {
                closeModal();
            }
        }

        // Auto-hide success and error messages
        document.addEventListener('DOMContentLoaded', function() {
            const successMessage = document.getElementById('successMessage');
            const errorMessage = document.getElementById('errorMessage');
            
            if (successMessage) {
                setTimeout(() => {
                    successMessage.style.opacity = '0';
                    setTimeout(() => {
                        successMessage.remove();
                    }, 500);
                }, 3000);
            }
            
            if (errorMessage) {
                setTimeout(() => {
                    errorMessage.style.opacity = '0';
                    setTimeout(() => {
                        errorMessage.remove();
                    }, 500);
                }, 5000);
            }
        });
    </script>
</body>
</html>