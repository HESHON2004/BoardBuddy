<?php
session_start();
include '../db.php';
require '../vendor/autoload.php'; // mPDF autoload

use Mpdf\Mpdf;

// ✅ Admin authentication
if (!isset($_SESSION['user_id']) || ($_SESSION['user_role'] ?? '') !== 'Admin') {
  header("Location: ../signin.php");
  exit;
}

// ✅ Get active/inactive counts
$query_active = "SELECT COUNT(*) AS count FROM users WHERE status = 'Active'";
$query_inactive = "SELECT COUNT(*) AS count FROM users WHERE status = 'Inactive'";

$active = $conn->query($query_active)->fetch_assoc()['count'] ?? 0;
$inactive = $conn->query($query_inactive)->fetch_assoc()['count'] ?? 0;
$total = $active + $inactive;

// ✅ Percentages
$activePercent = $total > 0 ? round(($active / $total) * 100, 2) : 0;
$inactivePercent = $total > 0 ? round(($inactive / $total) * 100, 2) : 0;

// ✅ Create chart config (bigger + labels)
$chartConfig = [
  'type' => 'pie',
  'data' => [
    'labels' => ['Active', 'Inactive'],
    'datasets' => [[
      'data' => [$active, $inactive],
      'backgroundColor' => ['#4CAF50', '#F44336'],
      'borderColor' => '#fff',
      'borderWidth' => 2
    ]]
  ],
  'options' => [
    'plugins' => [
      'legend' => [
        'position' => 'bottom',
        'labels' => [
          'font' => ['size' => 16]
        ]
      ],
      // ✅ Data labels (percentages)
      'datalabels' => [
        'color' => '#fff',
        'font' => ['size' => 16, 'weight' => 'bold'],
        'formatter' => 'function(value, context) {
          let sum = 0;
          let dataArr = context.chart.data.datasets[0].data;
          dataArr.map(data => sum += data);
          let percentage = (value * 100 / sum).toFixed(1) + "%";
          return percentage;
        }'
      ]
    ]
  ]
];

// ✅ QuickChart URL (bigger chart + plugin)
$chartUrl = "https://quickchart.io/chart?c=" . urlencode(json_encode($chartConfig)) . "&width=700&height=500&format=png&plugins=datalabels";

// ✅ Fetch chart image as base64
$chartImage = @file_get_contents($chartUrl);
$chartBase64 = $chartImage ? 'data:image/png;base64,' . base64_encode($chartImage) : null;

// ✅ Setup mPDF
$mpdf = new Mpdf([
  'allow_output_buffering' => true,
  'isRemoteEnabled' => true
]);
$mpdf->SetTitle('Active vs Inactive Users Report');

// ✅ Build PDF content
$html = '
  <h1 style="text-align:center; color:#333;">Active vs Inactive Users Report</h1>
  <p style="text-align:center; font-size:14px; color:#666;">Generated on: ' . date("Y-m-d H:i:s") . '</p>
  <hr style="margin:15px 0;">

  <h3 style="color:#333;">Summary</h3>
  <table style="width:100%; border-collapse:collapse; margin-bottom:15px; font-size:13px;">
    <tr>
      <th style="border:1px solid #ddd; padding:8px; background:#f0f0f0;">Status</th>
      <th style="border:1px solid #ddd; padding:8px; background:#f0f0f0;">Count</th>
      <th style="border:1px solid #ddd; padding:8px; background:#f0f0f0;">Percentage</th>
    </tr>
    <tr>
      <td style="border:1px solid #ddd; padding:8px;">Active Users</td>
      <td style="border:1px solid #ddd; padding:8px;">' . $active . '</td>
      <td style="border:1px solid #ddd; padding:8px;">' . $activePercent . '%</td>
    </tr>
    <tr>
      <td style="border:1px solid #ddd; padding:8px;">Inactive Users</td>
      <td style="border:1px solid #ddd; padding:8px;">' . $inactive . '</td>
      <td style="border:1px solid #ddd; padding:8px;">' . $inactivePercent . '%</td>
    </tr>
    <tr style="font-weight:bold;">
      <td style="border:1px solid #ddd; padding:8px;">Total</td>
      <td style="border:1px solid #ddd; padding:8px;">' . $total . '</td>
      <td style="border:1px solid #ddd; padding:8px;">100%</td>
    </tr>
  </table>
';

// ✅ Add chart (bigger & clearer)
if ($chartBase64) {
  $html .= '
    <div style="text-align:center; margin-top:25px;">
      <h3 style="color:#333;">User Status Distribution</h3>
      <img src="' . $chartBase64 . '" style="width:80%; max-width:600px;" />
    </div>
  ';
} else {
  $html .= '
    <p style="text-align:center; color:red;">⚠️ Chart could not be loaded. Check your internet connection.</p>
  ';
}

// ✅ Output PDF
$mpdf->WriteHTML($html);
$filename = 'Active_vs_Inactive_Users_Report_' . date("Ymd_His") . '.pdf';
$mpdf->Output($filename, 'D');
exit;
