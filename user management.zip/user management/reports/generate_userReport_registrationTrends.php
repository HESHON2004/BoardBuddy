<?php
session_start();
include '../db.php';
require '../vendor/autoload.php'; // mPDF autoload

use Mpdf\Mpdf;

// ✅ Ensure only admins can generate reports
if (!isset($_SESSION['user_id']) || ($_SESSION['user_role'] ?? '') !== 'Admin') {
    header("Location: ../signin.php");
    exit;
}

// ✅ Fetch monthly user registrations
$query = "
    SELECT DATE_FORMAT(created_at, '%Y-%m') AS month, COUNT(*) AS count
    FROM users
    GROUP BY month
    ORDER BY month ASC
";
$result = $conn->query($query);

$months = [];
$counts = [];
$total = 0;
$tableRows = '';

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $months[] = $row['month'];
        $counts[] = (int)$row['count'];
        $total += $row['count'];
    }
}

// ✅ Build table rows
foreach ($months as $i => $month) {
    $count = $counts[$i];
    $percentage = $total > 0 ? round(($count / $total) * 100, 2) : 0;
    $tableRows .= "
        <tr>
            <td style='border:1px solid #ddd; padding:8px;'>$month</td>
            <td style='border:1px solid #ddd; padding:8px;'>$count</td>
            <td style='border:1px solid #ddd; padding:8px;'>$percentage%</td>
        </tr>
    ";
}

// Total row
$tableRows .= "
    <tr style='font-weight:bold;'>
        <td style='border:1px solid #ddd; padding:8px;'>Total</td>
        <td style='border:1px solid #ddd; padding:8px;'>$total</td>
        <td style='border:1px solid #ddd; padding:8px;'>100%</td>
    </tr>
";

// ✅ Prepare line chart configuration
$chartConfig = [
    'type' => 'line',
    'data' => [
        'labels' => $months,
        'datasets' => [[
            'label' => 'User Registrations',
            'data' => $counts,
            'fill' => false,
            'borderColor' => '#16a34a',
            'backgroundColor' => '#16a34a',
            'tension' => 0.2
        ]]
    ],
    'options' => [
        'plugins' => [
            'legend' => [
                'display' => true,
                'position' => 'bottom'
            ]
        ],
        'scales' => [
            'x' => ['title' => ['display' => true, 'text' => 'Month']],
            'y' => ['title' => ['display' => true, 'text' => 'Registrations'], 'beginAtZero' => true]
        ]
    ]
];

// ✅ Generate chart URL and fetch base64
$chartUrl = "https://quickchart.io/chart?width=800&height=500&c=" . urlencode(json_encode($chartConfig));
$chartImage = @file_get_contents($chartUrl);
$chartBase64 = $chartImage ? 'data:image/png;base64,' . base64_encode($chartImage) : null;

// ✅ Generate PDF
$mpdf = new Mpdf([
    'allow_output_buffering' => true,
    'isRemoteEnabled' => true
]);
$mpdf->SetTitle('User Registration Trends Report');

$html = '
<h1 style="text-align:center; color:#333;">User Registration Trends Report</h1>
<p style="text-align:center; font-size:14px; color:#666;">Generated on: '.date("Y-m-d H:i:s").'</p>
<hr style="margin:15px 0;">

<h3 style="color:#333;">Monthly Registration Summary</h3>
<table style="width:100%; border-collapse:collapse; margin-bottom:15px; font-size:13px;">
    <tr>
        <th style="border:1px solid #ddd; padding:8px; background:#f0f0f0;">Month</th>
        <th style="border:1px solid #ddd; padding:8px; background:#f0f0f0;">Registrations</th>
        <th style="border:1px solid #ddd; padding:8px; background:#f0f0f0;">Percentage</th>
    </tr>'
    . $tableRows .
'</table>';

// Add chart
if ($chartBase64) {
    $html .= '
    <div style="text-align:center; margin-top:25px;">
        <h3 style="color:#333;">Registrations Trend Over Time</h3>
        <img src="'.$chartBase64.'" style="width:90%; max-width:700px;" />
    </div>';
} else {
    $html .= '<p style="text-align:center; color:red;">⚠️ Could not load chart. Please check your internet connection.</p>';
}

// Output PDF
$mpdf->WriteHTML($html);
$filename = 'User_Registration_Trends_Report_'.date("Ymd_His").'.pdf';
$mpdf->Output($filename, 'D');
exit;
?>