<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../styles/signin.css">
    <link rel="stylesheet" href="../styles/navigation.css">
    <title>Sign In - BoardBuddy</title>
</head>
<body>

    <!-- Navbar -->
    <?php include '../navigation/userNav.php'; ?>

    <div class="background"></div>

    <div class="container">
        <div class="signin-card">
            <?php if (isset($_GET['registered']) && $_GET['registered'] == 'success'): ?>
            <div id="successMessage" style="background: #10b981; color: white; padding: 12px 20px; border-radius: 8px; margin-bottom: 10px; text-align: center; font-weight: 500; transition: opacity 0.5s ease;">
                ✅ Registration successful! Please sign in with your credentials.
            </div>
            <?php endif; ?>
            
            <?php if (isset($_GET['error'])): ?>
            <div id="errorMessage" style="background: #dc2626; color: white; padding: 12px 20px; border-radius: 8px; margin-bottom: 10px; text-align: center; font-weight: 500; transition: opacity 0.5s ease;">
                <?php 
                if ($_GET['error'] == 'invalid') {
                    echo "❌ Invalid username or password. Please try again.";
                } elseif ($_GET['error'] == 'inactive') {
                    echo "⚠️ Your account is inactive. Please contact admin.";
                }
                ?>
            </div>
            <?php endif; ?>
            <div class="logo-section">
                <div class="logo">
                    <div class="logo-icon">🏠</div>
                    BoardBuddy
                </div>
                <h1 class="signin-title">Welcome Back</h1>
                <p class="signin-subtitle">Sign in to find your perfect housing</p>
            </div>

            <form class="form-section" id="signinForm" action="loginhandler.php" method="POST">
                <div class="form-group">
                    <label class="form-label" for="email">Email Address</label>
                    <input 
                        type="email" 
                        id="email" 
                        name="email" 
                        class="form-input" 
                        placeholder="info@xyz.com"
                        required
                    >
                </div>

                <div class="form-group">
                    <label class="form-label" for="password">Password</label>
                                            <input 
                            type="password" 
                            id="password" 
                            name="password" 
                            class="form-input" 
                            placeholder="••••••••"
                            required
                        >
                </div>

                <div class="checkbox-group">
                    <input type="checkbox" id="remember" name="remember" class="checkbox">
                    <label for="remember" class="checkbox-label">Remember me</label>
                    <a href="#" class="forgot-password" onclick="forgotPassword()">Forgot Password?</a>
                </div>

                <button type="submit" name="btnLogin" class="signin-btn">Sign In</button>
            </form>

            <div class="divider">
                <span>Or continue with</span>
            </div>

            <div class="social-section">
                <div class="social-buttons">
                    <a href="#" class="social-btn" onclick="signinWithGoogle()">
                        <svg class="social-icon" viewBox="0 0 24 24">
                            <path fill="#4285f4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                            <path fill="#34a853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                            <path fill="#fbbc05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                            <path fill="#ea4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                        </svg>
                        Google
                    </a>
                    <a href="#" class="social-btn" onclick="signinWithApple()">
                        <svg class="social-icon" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M12.152 6.896c-.948 0-2.415-1.078-3.96-1.04-2.04.027-3.91 1.183-4.961 3.014-2.117 3.675-.546 9.103 1.519 12.09 1.013 1.454 2.208 3.09 3.792 3.039 1.52-.065 2.09-.987 3.935-.987 1.831 0 2.35.987 3.96.948 1.637-.026 2.676-1.48 3.676-2.948 1.156-1.688 1.636-3.325 1.662-3.415-.039-.013-3.182-1.221-3.22-4.857-.026-3.04 2.48-4.494 2.597-4.559-1.429-2.09-3.623-2.324-4.39-2.376-2-.156-3.675 1.09-4.61 1.09zM15.53 3.83c.843-1.012 1.4-2.427 1.245-3.83-1.207.052-2.662.805-3.532 1.818-.78.896-1.454 2.338-1.273 3.714 1.338.104 2.715-.688 3.559-1.701"/>
                        </svg>
                        Apple
                    </a>
                </div>
            </div>

            <div class="signup-link">
                Don't have an account? <a href="signup.php" onclick="goToSignup()">Sign Up</a>
            </div>
        </div>
    </div>

    <script>
        document.getElementById('signinForm').addEventListener('submit', function(e) {
            // Only prevent if validation fails
            
            const formData = new FormData(this);
            const email = formData.get('email');
            const password = formData.get('password');
            const remember = formData.get('remember');
            
            if (!email || !password) {
                e.preventDefault();
                alert('Please fill in all required fields.');
                return;
            }
            
            // Show loading state (but don't disable the button)
            const btn = document.querySelector('.signin-btn');
            btn.textContent = 'Signing In...';
            // Don't disable the button - it prevents form submission
        });

        function signinWithGoogle() {
            console.log('Sign in with Google');
            alert('Google OAuth integration would be implemented here');
        }

        function signinWithApple() {
            console.log('Sign in with Apple');
            alert('Apple Sign In integration would be implemented here');
        }

        

        function forgotPassword() {
            console.log('Forgot password');
            alert('Password reset functionality would be implemented here');
        }

        // Auto-hide success and error messages after 3 seconds
        document.addEventListener('DOMContentLoaded', function() {
            const successMessage = document.getElementById('successMessage');
            const errorMessage = document.getElementById('errorMessage');
            
            if (successMessage) {
                setTimeout(() => {
                    successMessage.style.opacity = '0';
                    setTimeout(() => {
                        successMessage.remove();
                    }, 500); // Wait for fade transition to complete
                }, 3000); // Hide after 3 seconds
            }
            
            if (errorMessage) {
                setTimeout(() => {
                    errorMessage.style.opacity = '0';
                    setTimeout(() => {
                        errorMessage.remove();
                    }, 500); // Wait for fade transition to complete
                }, 5000); // Hide error after 5 seconds (longer for user to read)
            }
        });
    </script>
</body>
</html>