<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../styles/signup.css">
    <link rel="stylesheet" href="../styles/navigation.css">
    <title>Sign Up - BoardBuddy</title>
</head>
<body>
    <!-- Navbar -->
    <?php include '../navigation/userNav.php'; ?>

    <div class="background"></div>

    <div class="container">
        <div class="signup-card">
            <div class="logo-section">
                <div class="logo">
                    <div class="logo-icon">🏠</div>
                    BoardBuddy
                </div>
                <h1 class="signup-title">Create Account</h1>
                <p class="signup-subtitle">Join thousands of students finding perfect housing</p>
            </div>

            <form class="form-section" id="signupForm" action="registrationHandler.php" method="POST">
                <div class="form-grid">
                    <div class="form-group">
                        <label class="form-label" for="firstName">First Name</label>
                        <input 
                            type="text" 
                            id="firstName" 
                            name="first_name" 
                            class="form-input" 
                            placeholder="John"
                            required
                        >
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="lastName">Last Name</label>
                        <input 
                            type="text" 
                            id="lastName" 
                            name="last_name" 
                            class="form-input" 
                            placeholder="Doe"
                            required
                        >
                    </div>
                </div>

                                 <div class="form-grid">
                     <div class="form-group">
                         <label class="form-label" for="email">Email Address</label>
                         <input 
                             type="email" 
                             id="email" 
                             name="email" 
                             class="form-input" 
                             placeholder="info@xyz.com"
                             required
                         >
                     </div>
                     <div class="form-group">
                         <label class="form-label" for="mobile">Mobile No.</label>
                         <input 
                             type="tel" 
                             id="mobile" 
                             name="phone" 
                             class="form-input" 
                             placeholder="+91 - 98596 58000"
                             required
                         >
                     </div>
                 </div>

                <div class="form-grid">
                    <div class="form-group">
                        <label class="form-label" for="password">Password</label>
                        <input 
                            type="password" 
                            id="password" 
                            name="password" 
                            class="form-input" 
                            placeholder="••••••••"
                            required
                            minlength="8"
                        >
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="confirmPassword">Confirm Password</label>
                        <input 
                            type="password" 
                            id="confirmPassword" 
                            name="confirm_password" 
                            class="form-input" 
                            placeholder="••••••••"
                            required
                        >
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label" for="role">Account Type</label>
                    <select id="role" name="role" class="form-select" required>
                        <option value="">Select your role</option>
                        <option value="User">User</option>
                        <option value="Owner">Owner</option>
                        
                        
                    </select>
                </div>

                <div class="checkbox-group">
                    <input type="checkbox" id="terms" name="terms" class="checkbox" required>
                    <label for="terms" class="checkbox-label">
                        I agree to the <a href="#" onclick="showTerms()">Terms of Service</a> and 
                        <a href="#" onclick="showPrivacy()">Privacy Policy</a>
                    </label>
                </div>

                <button type="submit" name="btnSubmit" class="signup-btn">Create Account</button>
            </form>

            <div class="divider">
                <span>Or continue with</span>
            </div>

            <div class="social-section">
                <div class="social-buttons">
                    <a href="#" class="social-btn" onclick="signupWithGoogle()">
                        <svg class="social-icon" viewBox="0 0 24 24">
                            <path fill="#4285f4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                            <path fill="#34a853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                            <path fill="#fbbc05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                            <path fill="#ea4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                        </svg>
                        Google
                    </a>
                    <a href="#" class="social-btn" onclick="signupWithApple()">
                        <svg class="social-icon" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M12.152 6.896c-.948 0-2.415-1.078-3.96-1.04-2.04.027-3.91 1.183-4.961 3.014-2.117 3.675-.546 9.103 1.519 12.09 1.013 1.454 2.208 3.09 3.792 3.039 1.52-.065 2.09-.987 3.935-.987 1.831 0 2.35.987 3.96.948 1.637-.026 2.676-1.48 3.676-2.948 1.156-1.688 1.636-3.325 1.662-3.415-.039-.013-3.182-1.221-3.22-4.857-.026-3.04 2.48-4.494 2.597-4.559-1.429-2.09-3.623-2.324-4.39-2.376-2-.156-3.675 1.09-4.61 1.09zM15.53 3.83c.843-1.012 1.4-2.427 1.245-3.83-1.207.052-2.662.805-3.532 1.818-.78.896-1.454 2.338-1.273 3.714 1.338.104 2.715-.688 3.559-1.701"/>
                        </svg>
                        Apple
                    </a>
                </div>
            </div>

            <div class="login-link">
                Already have an account? <a href="signin.php" onclick="goToLogin()">Sign In</a>
            </div>
        </div>
    </div>

    <script>
        document.getElementById('signupForm').addEventListener('submit', function(e) {
            const formData = new FormData(this);
            const password = formData.get('password');
            const confirmPassword = formData.get('confirm_password');
            
            if (password !== confirmPassword) {
                e.preventDefault();
                alert('Passwords do not match!');
                return;
            }
            
            if (password.length < 8) {
                e.preventDefault();
                alert('Password must be at least 8 characters long!');
                return;
            }
            
            // Show loading state
            const btn = document.querySelector('.signup-btn');
            btn.innerHTML = 'Creating Account...';
            btn.disabled = true;
        });

        function signupWithGoogle() {
            console.log('Sign up with Google');
            alert('Google OAuth integration would be implemented here');
        }

        function signupWithApple() {
            console.log('Sign up with Apple');
            alert('Apple Sign In integration would be implemented here');
        }

        

        function showTerms() {
            console.log('Show terms of service');
            alert('Terms of Service modal would open here');
        }

        function showPrivacy() {
            console.log('Show privacy policy');
            alert('Privacy Policy modal would open here');
        }

        // Password strength indicator
        document.getElementById('password').addEventListener('input', function(e) {
            const password = e.target.value;
            const strength = getPasswordStrength(password);
            
            // You could add a visual indicator here
            console.log('Password strength:', strength);
        });

        function getPasswordStrength(password) {
            let strength = 0;
            if (password.length >= 8) strength++;
            if (/[A-Z]/.test(password)) strength++;
            if (/[0-9]/.test(password)) strength++;
            if (/[^A-Za-z0-9]/.test(password)) strength++;
            
            return ['Very Weak', 'Weak', 'Fair', 'Good', 'Strong'][strength];
        }
    </script>
</body>
</html>