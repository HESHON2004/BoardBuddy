<?php
session_start();

// Only allow admins
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'Admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

// Only allow POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$userId = intval($_POST['userId'] ?? 0);
if ($userId <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid user ID']);
    exit;
}

$con = mysqli_connect('localhost', 'root', '', 'boardbuddy', 3306);
if (!$con) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database connection failed']);
    exit;
}

// Delete user
$stmt = mysqli_prepare($con, 'DELETE FROM users WHERE id = ?');
mysqli_stmt_bind_param($stmt, 'i', $userId);
$success = mysqli_stmt_execute($stmt);
mysqli_stmt_close($stmt);
mysqli_close($con);

if ($success) {
    echo json_encode(['success' => true]);
} else {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Failed to delete user']);
}
?>
