<?php
session_start();
include '../db.php'; // correct path

if (!isset($_SESSION['user_id'])) {
    header("Location: signin.php");
    exit;
}

$userId = $_SESSION['user_id'];

// Directory to save uploaded images
$uploadDir = '../uploads/';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $firstName = $_POST['first_name'];
    $lastName  = $_POST['last_name'];
    $phone     = $_POST['phone'];
    $email     = $_POST['email'];

    $profilePicName = null;

    // Handle profile picture upload
    if (isset($_FILES['profile_pic']) && $_FILES['profile_pic']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['profile_pic']['tmp_name'];
        $fileName = basename($_FILES['profile_pic']['name']);
        $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

        // Allowed file types
        $allowed = ['jpg','jpeg','png','gif'];

        if (in_array($fileExt, $allowed)) {
            // Create a unique filename
            $newFileName = $userId . '_' . time() . '.' . $fileExt;
            $destPath = $uploadDir . $newFileName;

            if (move_uploaded_file($fileTmpPath, $destPath)) {
                $profilePicName = $newFileName;
            } else {
                die("Error: Failed to move uploaded file.");
            }
        } else {
            die("Error: Only JPG, PNG, GIF files allowed.");
        }
    }

    // Update user data
    if ($profilePicName) {
        $stmt = $conn->prepare("UPDATE users SET first_name=?, last_name=?, phone=?, email=?, profile_pic=? WHERE id=?");
        $stmt->bind_param("sssssi", $firstName, $lastName, $phone, $email, $profilePicName, $userId);
    } else {
        $stmt = $conn->prepare("UPDATE users SET first_name=?, last_name=?, phone=?, email=? WHERE id=?");
        $stmt->bind_param("ssssi", $firstName, $lastName, $phone, $email, $userId);
    }

    if ($stmt->execute()) {
        header("Location: ../profile.php?update=success");
        exit;
    } else {
        die("Error updating profile: " . $stmt->error);
    }
}
?>
