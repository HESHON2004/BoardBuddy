<?php
session_start();

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'Admin') {
    header("Location: signin.php");
    exit;
}

// Check if request is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: adminUser.php");
    exit;
}

// Get form data
$firstName = trim($_POST['firstName'] ?? '');
$lastName = trim($_POST['lastName'] ?? '');
$email = trim($_POST['email'] ?? '');
$phoneNumber = trim($_POST['phoneNumber'] ?? '');
$role = trim($_POST['role'] ?? '');
$status = trim($_POST['status'] ?? 'Active');
$password = $_POST['password'] ?? '';

// Validation
$errors = [];

if (empty($firstName)) {
    $errors[] = "First name is required";
}

if (empty($lastName)) {
    $errors[] = "Last name is required";
}

if (empty($email)) {
    $errors[] = "Email is required";
} elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = "Invalid email format";
}

if (!empty($phoneNumber) && !preg_match('/^[\+]?[0-9\s\-\(\)]{10,}$/', $phoneNumber)) {
    $errors[] = "Invalid phone number format";
}

if (empty($role)) {
    $errors[] = "Role is required";
} elseif (!in_array($role, ['Admin', 'User', 'Owner'])) {
    $errors[] = "Invalid role selected";
}

if (empty($password)) {
    $errors[] = "Password is required";
} elseif (strlen($password) < 6) {
    $errors[] = "Password must be at least 6 characters long";
}

if (!in_array($status, ['Active', 'Inactive'])) {
    $errors[] = "Invalid status selected";
}

// If there are validation errors, redirect back with errors
if (!empty($errors)) {
    $errorMessage = implode(', ', $errors);
    header("Location: adminUser.php?error=" . urlencode($errorMessage));
    exit;
}

// Connect to database
$con = mysqli_connect("localhost", "root", "", "boardbuddy", 3306);
if (!$con) {
    header("Location: adminUser.php?error=" . urlencode("Database connection failed"));
    exit;
}

// Check if email already exists
$checkQuery = "SELECT id FROM users WHERE email = ?";
$checkStmt = mysqli_prepare($con, $checkQuery);
mysqli_stmt_bind_param($checkStmt, "s", $email);
mysqli_stmt_execute($checkStmt);
$checkResult = mysqli_stmt_get_result($checkStmt);

if (mysqli_num_rows($checkResult) > 0) {
    mysqli_close($con);
    header("Location: ../adminUser.php?error=" . urlencode("Email already exists"));
    exit;
}

// Hash password
$passwordHash = password_hash($password, PASSWORD_DEFAULT);

// Insert new user
$insertQuery = "INSERT INTO users (first_name, last_name, email, phone, password_hash, role, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())";
$insertStmt = mysqli_prepare($con, $insertQuery);
mysqli_stmt_bind_param($insertStmt, "sssssss", $firstName, $lastName, $email, $phoneNumber, $passwordHash, $role, $status);

if (mysqli_stmt_execute($insertStmt)) {
    mysqli_close($con);
    header("Location: ../adminUser.php?success=" . urlencode("User added successfully"));
    exit;
} else {
    mysqli_close($con);
    header("Location: ../adminUser.php?error=" . urlencode("Failed to add user"));
    exit;
}
?>
