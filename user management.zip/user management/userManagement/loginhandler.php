<?php
session_start();
ob_start();

if (!isset($_POST["btnLogin"])) {
    header("Location: signin.php?error=invalid");
    exit;
}

$email = trim($_POST["email"]);
$password = $_POST["password"];

// 1. Connect to DB
$con = mysqli_connect("localhost", "root", "", "boardbuddy", 3306);
if (!$con) {
    die("Database connection failed: " . mysqli_connect_error());
}

// 2. Fetch user by email
$stmt = mysqli_prepare($con, "SELECT id, first_name, last_name, password_hash, role, status FROM users WHERE email = ?");
mysqli_stmt_bind_param($stmt, "s", $email);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if ($row = mysqli_fetch_assoc($result)) {
    // Verify password first
    if (password_verify($password, $row['password_hash'])) {

        // 3. Update last_login and activate user if inactive
        $updateStmt = mysqli_prepare(
            $con,
            "UPDATE users SET last_login = NOW(), status = 'Active' WHERE id = ?"
        );
        mysqli_stmt_bind_param($updateStmt, "i", $row['id']);
        mysqli_stmt_execute($updateStmt);

        // 4. Store user session
        $_SESSION["user_id"] = $row['id'];
        $_SESSION["user_name"] = $row['first_name'] . " " . $row['last_name'];
        $_SESSION["user_email"] = $email;
        $_SESSION["user_role"] = $row['role'];

        // 5. Redirect based on role
        $redirects = [
            'Admin' => '../adminDash.php',
            'Owner' => '../ownerHome.php',
            'User'  => '../userHome.php'
        ];
        header("Location: " . ($redirects[$row['role']] ?? '../userHome.php'));
        exit;
    } else {
        // Wrong password
        header("Location: signin.php?error=invalid");
        exit;
    }
} else {
    // Email not found
    header("Location: signin.php?error=invalid");
    exit;
}
?>
