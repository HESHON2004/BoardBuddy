<?php
session_start();
include 'db.php';

// Check admin login
if (!isset($_SESSION['user_id']) || ($_SESSION['user_role'] ?? '') !== 'Admin') {
    header("Location: signin.php");
    exit;
}

// Default pagination settings
$limit = 20;
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? intval($_GET['page']) : 1;
$offset = ($page - 1) * $limit;

// Filter variables
$userFilter = $_GET['user'] ?? '';
$actionFilter = $_GET['action'] ?? '';
$startDate = $_GET['start_date'] ?? '';
$endDate = $_GET['end_date'] ?? '';

// Base query
$sql = "
  SELECT a.action, a.created_at, u.first_name, u.last_name
  FROM activity_log a
  LEFT JOIN users u ON a.user_id = u.id
  WHERE 1=1
";

// Apply filters dynamically
if (!empty($userFilter)) {
    $userFilterEscaped = $conn->real_escape_string($userFilter);
    $sql .= " AND (u.first_name LIKE '%$userFilterEscaped%' OR u.last_name LIKE '%$userFilterEscaped%')";
}
if (!empty($actionFilter)) {
    $actionFilterEscaped = $conn->real_escape_string($actionFilter);
    $sql .= " AND a.action LIKE '%$actionFilterEscaped%'";
}
if (!empty($startDate) && !empty($endDate)) {
    $startDateEscaped = $conn->real_escape_string($startDate);
    $endDateEscaped = $conn->real_escape_string($endDate);
    $sql .= " AND DATE(a.created_at) BETWEEN '$startDateEscaped' AND '$endDateEscaped'";
}

// Get total count for pagination
$countSql = str_replace("SELECT a.action, a.created_at, u.first_name, u.last_name", "SELECT COUNT(*) AS total", $sql);
$totalResult = $conn->query($countSql);
$totalRecords = $totalResult ? $totalResult->fetch_assoc()['total'] : 0;
$totalPages = ceil($totalRecords / $limit);

// Add ordering and pagination
$sql .= " ORDER BY a.created_at DESC LIMIT $limit OFFSET $offset";
$activities = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>All Activities - Admin</title>
  <link rel="stylesheet" href="styles/shared.css">
  <style>
    .header {
      margin-bottom: 25px;
    }
    .header h1 { font-size: 28px; font-weight: 600; }
    .header p { color: #666; margin-top: 5px; }

    .filter-box {
      background: white;
      padding: 16px;
      border-radius: 10px;
      box-shadow: 0 2px 6px rgba(0,0,0,0.05);
      margin-bottom: 20px;
    }
    .filter-box form {
      display: flex;
      flex-wrap: wrap;
      gap: 10px;
      align-items: center;
    }
    .filter-box input {
      padding: 8px 10px;
      border: 1px solid #ddd;
      border-radius: 6px;
    }
    .filter-box button {
      background: #2563eb;
      color: white;
      border: none;
      padding: 8px 14px;
      border-radius: 6px;
      cursor: pointer;
      transition: 0.2s;
    }
    .filter-box button:hover { background: #1e40af; }

    table {
      width: 100%;
      border-collapse: collapse;
      background: white;
      border-radius: 12px;
      overflow: hidden;
      box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    }
    th, td {
      padding: 14px 16px;
      border-bottom: 1px solid #f1f1f1;
      text-align: left;
    }
    th {
      background: #f9fafb;
      font-weight: 600;
    }
    tr:hover td {
      background: #f9fafb;
    }

    .pagination {
      margin-top: 20px;
      text-align: center;
    }
    .pagination a {
      display: inline-block;
      margin: 0 4px;
      padding: 6px 12px;
      border-radius: 6px;
      text-decoration: none;
      background: #f1f5f9;
      color: #2563eb;
      font-weight: 500;
    }
    .pagination a.active {
      background: #2563eb;
      color: white;
    }
    .pagination a:hover {
      background: #93c5fd;
      color: white;
    }
  </style>
</head>
<body>
<div class="container-main">
  <!-- Sidebar -->
  <div class="sidebar">
    <div class="logo">
      <h2>ADMIN</h2>
      <p style="color:#94a3b8; font-size:14px; margin-top:10px;">
        Welcome, <?php echo htmlspecialchars($_SESSION['user_name']); ?>
      </p>
    </div>
    <ul class="nav-menu">
      <li class="nav-item" onclick="location.href='adminDash.php'">Dashboard</li>
      <li class="nav-item" onclick="location.href='adminUser.php'">User Management</li>
      <li class="nav-item active" onclick="location.href='allActivities.php'">All Activities</li>
      <li class="nav-item" onclick="location.href='adminReports.php'">Reports</li>
      <li class="nav-item" onclick="location.href='adminNotifications.php'">Notifications</li>
      <li class="nav-item">Payments</li>
    </ul>
  </div>

  <!-- Main Content -->
  <div class="main-content">
    <div class="header">
      <h1>All Activities</h1>
      <p>Complete log of system activities (<?= $totalRecords ?> total)</p>
    </div>

    <!-- Filter Box -->
    <div class="filter-box">
      <form method="GET" action="">
        <input type="text" name="user" placeholder="Search by User" value="<?php echo htmlspecialchars($userFilter); ?>">
        <input type="text" name="action" placeholder="Search by Action" value="<?php echo htmlspecialchars($actionFilter); ?>">
        <input type="date" name="start_date" value="<?php echo htmlspecialchars($startDate); ?>">
        <input type="date" name="end_date" value="<?php echo htmlspecialchars($endDate); ?>">
        <button type="submit">Filter</button>
        <button type="button" onclick="window.location='allActivities.php'">Reset</button>
      </form>
    </div>

    <!-- Table -->
    <table>
      <thead>
        <tr>
          <th>User</th>
          <th>Action</th>
          <th>Time</th>
        </tr>
      </thead>
      <tbody>
        <?php if ($activities && $activities->num_rows > 0): ?>
          <?php while($a = $activities->fetch_assoc()): ?>
          <tr>
            <td><?php echo htmlspecialchars(trim($a['first_name'] . ' ' . $a['last_name'])); ?></td>
            <td><?php echo htmlspecialchars($a['action']); ?></td>
            <td><?php echo date('M d, Y H:i', strtotime($a['created_at'])); ?></td>
          </tr>
          <?php endwhile; ?>
        <?php else: ?>
          <tr><td colspan="3" style="text-align:center; color:#666;">No activities found.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>

    <!-- Pagination -->
    <?php if ($totalPages > 1): ?>
      <div class="pagination">
        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
          <a href="?<?php
            $query = $_GET;
            $query['page'] = $i;
            echo http_build_query($query);
          ?>" class="<?php echo ($i == $page) ? 'active' : ''; ?>">
            <?php echo $i; ?>
          </a>
        <?php endfor; ?>
      </div>
    <?php endif; ?>

  </div>
</div>
</body>
</html>
