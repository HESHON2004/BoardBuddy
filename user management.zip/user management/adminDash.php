<?php
session_start();
include 'db.php';

// Check admin login
if (!isset($_SESSION['user_id']) || ($_SESSION['user_role'] ?? '') !== 'Admin') {
    header("Location: signin.php");
    exit;
}

// Fetch dashboard stats
$total_users = $conn->query("SELECT COUNT(*) AS total FROM users")->fetch_assoc()['total'] ?? 0;
$total_properties = $conn->query("SELECT COUNT(*) AS total FROM properties")->fetch_assoc()['total'] ?? 0;
$total_inquiries = $conn->query("SELECT COUNT(*) AS total FROM inquiries")->fetch_assoc()['total'] ?? 0;
$inactive_users = $conn->query("SELECT COUNT(*) AS total FROM users WHERE status='Inactive'")->fetch_assoc()['total'] ?? 0;

// Fetch recent activities
$activities_sql = "
  SELECT a.action, a.created_at, u.first_name, u.last_name
  FROM activity_log a
  LEFT JOIN users u ON a.user_id = u.id
  ORDER BY a.created_at DESC
  LIMIT 5
";
$activities = $conn->query($activities_sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Dashboard</title>
  <link rel="stylesheet" href="styles/shared.css">

  <!-- Page-specific CSS -->
  <style>
    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 30px;
    }
    .header h1 { font-size: 28px; font-weight: 600; }
    .header p { color: #666; margin-top: 5px; }
    .header div { display: flex; flex-direction: column; }

    .logout-btn {
      background: #dc2626;
      color: white;
      padding: 10px 20px;
      border-radius: 8px;
      text-decoration: none;
      font-weight: 500;
      transition: background 0.2s;
    }
    .logout-btn:hover { background: #b91c1c; }

    .summary-cards {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 20px;
      margin-top: 25px;
    }
    .card-box {
      background: white;
      border-radius: 12px;
      padding: 25px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    }
    .card-box h3 {
      font-size: 16px;
      color: #666;
      margin-bottom: 10px;
    }
    .card-box p {
      font-size: 28px;
      font-weight: bold;
      margin: 0;
    }

    /* Recent Activities Section */
    .recent-activities {
      margin-top: 40px;
      background: white;
      border-radius: 12px;
      padding: 25px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    }
    .recent-activities h2 {
      font-size: 20px;
      margin-bottom: 20px;
      font-weight: 600;
    }
    .activity-item {
      display: flex;
      justify-content: space-between;
      padding: 10px 0;
      border-bottom: 1px solid #f1f1f1;
    }
    .activity-item:last-child {
      border-bottom: none;
    }
    .activity-user {
      font-weight: 500;
      color: #1e293b;
    }
    .activity-action {
      color: #475569;
    }
    .activity-time {
      font-size: 14px;
      color: #94a3b8;
    }
  </style>
</head>
<body>
<div class="container-main">
  <!-- Sidebar -->
  <div class="sidebar">
    <div class="logo">
      <h2>ADMIN</h2>
      <p style="color:#94a3b8; font-size:14px; margin-top:10px;">
        Welcome, <?php echo htmlspecialchars($_SESSION['user_name']); ?>
      </p>
    </div>
    <ul class="nav-menu">
      <li class="nav-item active">Dashboard</li>
      <li class="nav-item" onclick="location.href='adminUser.php'">User Management</li>
      <li class="nav-item" onclick="location.href='allActivities.php'">All Activities</li>
      <li class="nav-item" onclick="location.href='adminReports.php'">Reports</li>
      <li class="nav-item" onclick="location.href='adminNotifications.php'">Notifications</li>
      <li class="nav-item">Payments</li>
    </ul>
  </div>

  <!-- Main Content -->
  <div class="main-content">
    <div class="header">
      <div>
        <h1>Dashboard</h1>
        <p>Overview of system activity and statistics</p>
      </div>
      <a href="userManagement/logout.php" class="logout-btn">Logout</a>
    </div>

    <!-- Summary Cards -->
    <div class="summary-cards">
      <div class="card-box">
        <h3>Total Users</h3>
        <p><?php echo $total_users; ?></p>
      </div>
      <div class="card-box">
        <h3>Total Properties</h3>
        <p><?php echo $total_properties; ?></p>
      </div>
      <div class="card-box">
        <h3>Total Inquiries</h3>
        <p><?php echo $total_inquiries; ?></p>
      </div>
      <div class="card-box">
        <h3>Inactive Users</h3>
        <p><?php echo $inactive_users; ?></p>
      </div>
    </div>

    

    <!-- Recent Activities -->
    <div class="recent-activities">
      <h2>Recent Activities</h2>
      <?php if ($activities && $activities->num_rows > 0): ?>
        <?php while($a = $activities->fetch_assoc()): ?>
          <div class="activity-item">
            <div>
              <span class="activity-user">
                <?php echo htmlspecialchars($a['first_name'] . ' ' . $a['last_name']); ?>
              </span>
              <span class="activity-action"> - <?php echo htmlspecialchars($a['action']); ?></span>
            </div>
            <span class="activity-time">
              <?php echo date('M d, Y H:i', strtotime($a['created_at'])); ?>
            </span>
          </div>
        <?php endwhile; ?>
      <?php else: ?>
        <p style="color:#94a3b8;">No recent activities.</p>
      <?php endif; ?>
      <div style="text-align: right; margin-top: 10px;">
        <a href="allActivities.php" style="color:#3b82f6; font-weight:500; text-decoration:none;">
            See More &rarr;
        </a>
    </div>
    </div>



  </div>
</div>
</body>
</html>
