<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: signin.php");
    exit;
}

// Check if user is admin
if ($_SESSION['user_role'] !== 'Admin') {
    header("Location: signin.php");
    exit;
}

// Connect to database
$con = mysqli_connect("localhost", "root", "", "user_management", 3306);
if (!$con) {
    die("Database connection failed: " . mysqli_connect_error());
}

// Fetch users from database
$query = "SELECT id, first_name, last_name, email, phone, role, status, created_at FROM users ORDER BY created_at DESC";
$result = mysqli_query($con, $query);

$users = [];
if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        $users[] = [
            'id' => $row['id'],
            'name' => $row['first_name'] . ' ' . $row['last_name'],
            'email' => $row['email'],
            'phone' => $row['phone'] ?? '',
            'role' => $row['role'],
            'status' => $row['status'],
            'lastLogin' => 'Recently' // You can add last_login field to your database if needed
        ];
    }
}

mysqli_close($con);

// Handle success/error messages
$successMessage = '';
$errorMessage = '';

if (isset($_GET['success'])) {
    $successMessage = htmlspecialchars($_GET['success']);
}

if (isset($_GET['error'])) {
    $errorMessage = htmlspecialchars($_GET['error']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management - Admin Panel</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background-color: #f5f5f7;
            color: #333;
        }

        .container {
            display: flex;
            min-height: 100vh;
        }

        .sidebar {
            width: 250px;
            background: #02113c;
            border-right: 1px solid #1e40af;
            padding: 20px 0;
        }

        .logo {
            padding: 0 20px 30px;
            border-bottom: 1px solid #3b82f6;
        }

        .logo h2 {
            color: #ffffff;
            font-size: 18px;
        }

        .nav-menu {
            list-style: none;
            padding: 20px 0;
        }

        .nav-item {
            padding: 12px 20px;
            cursor: pointer;
            transition: background 0.2s;
            color: #e2e8f0;
        }

        .nav-item:hover {
            background-color: #3b82f6;
        }

        .nav-item.active {
            background-color: #3b82f6;
            color: white;
        }

        .main-content {
            flex: 1;
            padding: 30px;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        .header h1 {
            font-size: 28px;
            font-weight: 600;
        }

        .header p {
            color: #666;
            margin-top: 5px;
        }

        .add-user-btn {
            background: #007aff;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            transition: background 0.2s;
        }

        .add-user-btn:hover {
            background: #0056b3;
        }

        .user-directory {
            background: white;
            border-radius: 12px;
            padding: 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }

        .directory-header {
            display: flex;
            justify-content: between;
            align-items: center;
            margin-bottom: 20px;
        }

        .directory-title {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 5px;
        }

        .directory-subtitle {
            color: #666;
            font-size: 14px;
        }

        .search-filters {
            display: flex;
            gap: 15px;
            margin: 20px 0;
            align-items: center;
        }

        .search-box {
            flex: 1;
            max-width: 800px;
            position: relative;
        }

        .search-box input {
            width: 100%;
            padding: 10px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
        }

        .filter-dropdown {
            padding: 10px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            background: white;
            cursor: pointer;
            min-width: 160px;
        }

        .user-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .user-table th {
            background: #f8f9fa;
            padding: 15px;
            text-align: left;
            font-weight: 600;
            font-size: 12px;
            text-transform: uppercase;
            color: #666;
            border-bottom: 1px solid #e5e5e7;
        }

        .user-table td {
            padding: 15px;
            border-bottom: 1px solid #f0f0f0;
        }

        .user-table tbody tr:hover {
            background-color: #fafafa;
        }

        .status-badge {
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }

        .status-active {
            background: #e8f5e8;
            color: #2d7d2d;
        }

        .status-inactive {
            background: #fff3cd;
            color: #856404;
        }

        .actions-menu {
            position: relative;
            display: inline-block;
        }

        .actions-btn {
            background: none;
            border: none;
            cursor: pointer;
            padding: 8px;
            border-radius: 6px;
            margin: 0 2px;
            color: #6b7280;
            transition: all 0.2s ease;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 32px;
            height: 32px;
        }

        .actions-btn svg {
            width: 18px;
            height: 18px;
            fill: currentColor;
        }

        .actions-btn:hover {
            background: #f3f4f6;
            color: #374151;
            transform: translateY(-1px);
        }

        .actions-btn.edit:hover {
            background: #dbeafe;
            color: #2563eb;
        }
        .actions-btn.delete{
            color: #dc2626;
        }
        .actions-btn.delete:hover {
            background: #fee2e2;
            color: #dc2626;
        }


        .email-link {
            color: #007aff;
            text-decoration: none;
        }

        .email-link:hover {
            text-decoration: underline;
        }

        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 2000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
        }

        .modal-content {
            background-color: white;
            margin: 5% auto;
            padding: 18px;
            border-radius: 12px;
            width: 90%;
            max-width: 500px;
        }

        .modal h2 {
            margin-bottom: 20px;
            font-size: 24px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
        }

        .modal-actions {
            display: flex;
            gap: 10px;
            justify-content: flex-end;
            margin-top: 23px;
        }

        .btn-cancel {
            background: #f0f0f0;
            color: #333;
            border: none;
            padding: 8px 16px;
            border-radius: 8px;
            cursor: pointer;
        }

        .btn-save {
            background: #007aff;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 8px;
            cursor: pointer;
        }

        /* Message animations */
        #successMessage, #errorMessage {
            transition: opacity 0.5s ease;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo">
                <h2>ADMIN</h2>
                <p style="color: #94a3b8; font-size: 14px; margin-top: 10px;">Welcome, <?php echo htmlspecialchars($_SESSION['user_name']); ?></p>
            </div>
            <ul class="nav-menu">
                <li class="nav-item"> Dashboard</li>
                <li class="nav-item active"> User Management</li>
                <li class="nav-item"> Reports</li>
                <li class="nav-item"> Payments</li>
                <li class="nav-item"> Settings</li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <?php if (!empty($successMessage)): ?>
            <div id="successMessage" style="background: #10b981; color: white; padding: 12px 20px; border-radius: 8px; margin-bottom: 20px; text-align: center; font-weight: 500;">
                ✅ <?php echo $successMessage; ?>
            </div>
            <?php endif; ?>
            
            <?php if (!empty($errorMessage)): ?>
            <div id="errorMessage" style="background: #dc2626; color: white; padding: 12px 20px; border-radius: 8px; margin-bottom: 20px; text-align: center; font-weight: 500;">
                ❌ <?php echo $errorMessage; ?>
            </div>
            <?php endif; ?>
            
            <div class="header">
                <div>
                    <h1>User Management</h1>
                    <p>Manage Users, Owners, and administrative staff</p>
                </div>
                <div style="display: flex; gap: 10px; align-items: center;">
                    <button class="add-user-btn" onclick="openAddUserModal()">+ Add New User</button>
                    <a href="signin.php" style="background: #dc2626; color: white; padding: 10px 20px; border-radius: 8px; text-decoration: none; font-size: 14px; font-weight: 500;">Logout</a>
                </div>
            </div>

            <div class="user-directory">
                <div class="directory-header">
                    <div>
                        <h3 class="directory-title">User Directory</h3>
                        <p class="directory-subtitle">Search and filter system users (<span id="user-count"><?php echo count($users); ?></span> users)</p>
                    </div>
                </div>

                <div class="search-filters">
                    <div class="search-box">
                        <input type="text" id="searchInput" placeholder="Search by name or email..." onkeyup="filterUsers()">
                    </div>
                    <select class="filter-dropdown" id="roleFilter" onchange="filterUsers()">
                        <option value="">All Roles</option>
                        <option value="Admin">Admin</option>
                        <option value="User">User</option>
                        <option value="Owner">Owner</option>
                    </select>
                    <select class="filter-dropdown" id="statusFilter" onchange="filterUsers()">
                        <option value="">All Status</option>
                        <option value="Active">Active</option>
                        <option value="Inactive">Inactive</option>
                    </select>
                </div>

                <table class="user-table">
                    <thead>
                        <tr>
                            <th>NAME</th>
                            <th>EMAIL</th>
                            <th>PHONE</th>
                            <th>ROLE</th>
                            <th>STATUS</th>
                            <th>LAST LOGIN</th>
                            <th>ACTIONS</th>
                        </tr>
                    </thead>
                    <tbody id="userTableBody">
                        <!-- User rows will be populated by JavaScript -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Add/Edit User Modal -->
    <div id="userModal" class="modal">
        <div class="modal-content">
            <h2 id="modalTitle">Add New User</h2>
            <form id="userForm" action="" method="POST">
                <input type="hidden" id="userId" name="userId">
                <input type="hidden" id="formMode" name="formMode" value="add">
                <div class="form-group">
                    <label for="firstName">First Name</label>
                    <input type="text" id="firstName" name="firstName" required>
                </div>
                <div class="form-group">
                    <label for="lastName">Last Name</label>
                    <input type="text" id="lastName" name="lastName" required>
                </div>
                <div class="form-group">
                    <label for="userEmail">Email Address</label>
                    <input type="email" id="userEmail" name="email" required>
                </div>
                <div class="form-group">
                    <label for="phoneNumber">Phone Number</label>
                    <input type="tel" id="phoneNumber" name="phoneNumber" placeholder="+1234567890">
                </div>
                <div class="form-group">
                    <label for="password">Password <span id="passwordNote" style="color: #666; font-size: 12px; display: none;">(Leave blank to keep current password)</span></label>
                    <input type="password" id="password" name="password" minlength="6">
                </div>
                <div class="form-group">
                    <label for="userRole">Role</label>
                    <select id="userRole" name="role" required>
                        <option value="">Select Role</option>
                        <option value="Admin">Admin</option>
                        <option value="User">User</option>
                        <option value="Owner">Owner</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="userStatus">Status</label>
                    <select id="userStatus" name="status" required>
                        <option value="Active">Active</option>
                        <option value="Inactive">Inactive</option>
                    </select>
                </div>
                <div class="modal-actions">
                    <button type="button" class="btn-cancel" onclick="closeModal()">Cancel</button>
                    <button type="submit" class="btn-save">Save User</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // User data from PHP backend
        let users = <?php echo json_encode($users); ?>;

        let currentEditId = null;

        // Initialize the page
        document.addEventListener('DOMContentLoaded', function() {
            renderUsers();
            updateUserCount();
        });

        // Render users in table
        function renderUsers(filteredUsers = users) {
            const tbody = document.getElementById('userTableBody');
            tbody.innerHTML = '';

            if (filteredUsers.length === 0) {
                tbody.innerHTML = '<tr><td colspan="7" style="text-align: center; padding: 40px; color: #666;">No users found</td></tr>';
                return;
            }

            filteredUsers.forEach(user => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td><strong>${user.name}</strong></td>
                    <td><a href="mailto:${user.email}" class="email-link">${user.email}</a></td>
                    <td>${user.phone || 'N/A'}</td>
                    <td>${user.role}</td>
                    <td><span class="status-badge ${user.status === 'Active' ? 'status-active' : 'status-inactive'}">${user.status}</span></td>
                    <td>${user.lastLogin}</td>
                    <td>
                        <div class="actions-menu">
                            <button class="actions-btn edit" onclick="editUser(${user.id})" title="Edit User">
                                <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/>
                                </svg>
                            </button>
                            <button class="actions-btn delete" onclick="deleteUser(${user.id})" title="Delete User">
                                <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/>
                                </svg>
                            </button>
                        </div>
                    </td>
                `;
                tbody.appendChild(row);
            });

            updateUserCount(filteredUsers.length);
        }

        // Filter users
        function filterUsers() {
            const searchTerm = document.getElementById('searchInput').value.toLowerCase();
            const roleFilter = document.getElementById('roleFilter').value;
            const statusFilter = document.getElementById('statusFilter').value;

            const filtered = users.filter(user => {
                const matchesSearch = user.name.toLowerCase().includes(searchTerm) || 
                                    user.email.toLowerCase().includes(searchTerm);
                const matchesRole = !roleFilter || user.role === roleFilter;
                const matchesStatus = !statusFilter || user.status === statusFilter;

                return matchesSearch && matchesRole && matchesStatus;
            });

            renderUsers(filtered);
        }


        // Open add user modal
        function openAddUserModal() {
            document.getElementById('modalTitle').textContent = 'Add New User';
            document.getElementById('formMode').value = 'add';
            document.getElementById('userForm').reset();
            document.getElementById('userId').value = '';
            document.getElementById('firstName').value = '';
            document.getElementById('lastName').value = '';
            document.getElementById('userEmail').value = '';
            document.getElementById('phoneNumber').value = '';
            document.getElementById('password').value = '';
            document.getElementById('userRole').value = '';
            document.getElementById('userStatus').value = 'Active';
            document.getElementById('password').required = true;
            document.getElementById('passwordNote').style.display = 'none';
            currentEditId = null;
            document.getElementById('userModal').style.display = 'block';
        }

        // Edit user
        function editUser(userId) {
            const user = users.find(u => u.id == userId);
            if (user) {
                document.getElementById('modalTitle').textContent = 'Edit User';
                document.getElementById('formMode').value = 'edit';
                document.getElementById('userId').value = user.id;
                
                // Split the full name into first and last name
                const nameParts = user.name.split(' ');
                const firstName = nameParts[0] || '';
                const lastName = nameParts.slice(1).join(' ') || '';
                
                document.getElementById('firstName').value = firstName;
                document.getElementById('lastName').value = lastName;
                document.getElementById('userEmail').value = user.email;
                document.getElementById('phoneNumber').value = user.phone || '';
                document.getElementById('password').value = '';
                document.getElementById('userRole').value = user.role;
                document.getElementById('userStatus').value = user.status;
                document.getElementById('password').required = false;
                document.getElementById('passwordNote').style.display = 'inline';
                currentEditId = userId;
                document.getElementById('userModal').style.display = 'block';
            }
        }

        // Fetch users from backend and update table
        function fetchUsersAndRender() {
            fetch(window.location.href, { method: 'GET' })
                .then(response => response.text())
                .then(html => {
                    // Extract users JSON from PHP
                    const match = html.match(/let users = (.*?);/);
                    if (match && match[1]) {
                        users = JSON.parse(match[1]);
                        renderUsers();
                        updateUserCount();
                    }
                });
        }

        // Delete user
        function deleteUser(userId) {
            if (confirm('Are you sure you want to delete this user?')) {
                fetch('delete_user_handler.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: 'userId=' + encodeURIComponent(userId)
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showSuccessMessage('User deleted successfully!');
                        fetchUsersAndRender();
                    } else {
                        alert('Failed to delete user: ' + (data.message || 'Unknown error'));
                    }
                })
                .catch(() => {
                    alert('Failed to delete user: Network error');
                });
            }
        }

        // Show success message dynamically
        function showSuccessMessage(message) {
            // Remove any existing success message
            const oldMsg = document.getElementById('successMessage');
            if (oldMsg) oldMsg.remove();
            // Create new message div
            const msgDiv = document.createElement('div');
            msgDiv.id = 'successMessage';
            msgDiv.style.background = '#10b981';
            msgDiv.style.color = 'white';
            msgDiv.style.padding = '12px 20px';
            msgDiv.style.borderRadius = '8px';
            msgDiv.style.marginBottom = '20px';
            msgDiv.style.textAlign = 'center';
            msgDiv.style.fontWeight = '500';
            msgDiv.textContent = '✅ ' + message;
            // Insert at top of main-content
            const mainContent = document.querySelector('.main-content');
            mainContent.insertBefore(msgDiv, mainContent.firstChild);
            // Auto-hide after 3 seconds
            setTimeout(() => {
                msgDiv.style.opacity = '0';
                setTimeout(() => {
                    msgDiv.remove();
                }, 500);
            }, 3000);
        }

        // Close modal
        function closeModal() {
            document.getElementById('userModal').style.display = 'none';
        }

        // Handle form submission
        document.getElementById('userForm').addEventListener('submit', function(e) {
            const formMode = document.getElementById('formMode').value;
            const form = document.getElementById('userForm');
            
            // Set the correct action based on mode
            if (formMode === 'add') {
                form.action = 'add_user_handler.php';
            } else {
                form.action = 'edit_user_handler.php';
            }
            
            // For add mode, password is required
            if (formMode === 'add') {
                const passwordField = document.getElementById('password');
                passwordField.required = true;
            } else {
                // For edit mode, password is optional
                const passwordField = document.getElementById('password');
                passwordField.required = false;
            }
        });

        // Update user count
        function updateUserCount(count = users.length) {
            document.getElementById('user-count').textContent = count;
        }

        // Close modal when clicking outside
        window.onclick = function(event) {
            const modal = document.getElementById('userModal');
            if (event.target === modal) {
                closeModal();
            }
        }

        // Auto-hide success and error messages
        document.addEventListener('DOMContentLoaded', function() {
            const successMessage = document.getElementById('successMessage');
            const errorMessage = document.getElementById('errorMessage');
            
            if (successMessage) {
                setTimeout(() => {
                    successMessage.style.opacity = '0';
                    setTimeout(() => {
                        successMessage.remove();
                    }, 500);
                }, 3000);
            }
            
            if (errorMessage) {
                setTimeout(() => {
                    errorMessage.style.opacity = '0';
                    setTimeout(() => {
                        errorMessage.remove();
                    }, 500);
                }, 5000);
            }
        });
    </script>
</body>
</html>