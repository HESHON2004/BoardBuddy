<?php
session_start();


if (isset($_POST["btnLogin"])) {
    $email = $_POST["email"];
    $password = $_POST["password"];
    
    

    // 1. Connect to DB
    $con = mysqli_connect("localhost", "root", "", "user_management", 3306);
    if (!$con) {
        die("Database connection failed: " . mysqli_connect_error());
    }
    

    // 2. Fetch user by email
    $stmt = mysqli_prepare($con, "SELECT id, first_name, last_name, password_hash, role, status FROM users WHERE email = ?");
    mysqli_stmt_bind_param($stmt, "s", $email);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($row = mysqli_fetch_assoc($result)) {
        
        
        // 3. Check if account is active
        if ($row['status'] !== 'Active') {
            header("Location: signin.php?error=inactive");
            exit;
        }
        

        
        
        if (password_verify($password, $row['password_hash'])) {
            
            // Login success → Save session
            $_SESSION["user_id"] = $row['id'];
            $_SESSION["user_name"] = $row['first_name'] . " " . $row['last_name'];
            $_SESSION["user_email"] = $email;
            $_SESSION["user_role"] = $row['role'];

            // 5. Redirect based on role
            if ($row['role'] === 'Admin') {
                header("Location: AdminPanel.php");
            } elseif ($row['role'] === 'Owner') {
                header("Location: owner_dashboard.php");
            } else {
                header("Location: user_dashboard.php");
            }
            exit;
        } else {
            header("Location: signin.php?error=invalid");
            exit;
        }
    } else {
        header("Location: signin.php?error=invalid");
        exit;
    }
} else {
    header("Location: signin.php?error=invalid");
    exit;
}
?>
