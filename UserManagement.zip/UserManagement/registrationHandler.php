<?php
session_start();

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Debug: Log all POST data
error_log("POST data received: " . print_r($_POST, true));

if (isset($_POST["btnSubmit"])) {
    $firstName = $_POST["first_name"];
    $lastName  = $_POST["last_name"];
    $email     = $_POST["email"];
    $phone     = $_POST["phone"];
    $password  = $_POST["password"];
    $conf_pass = $_POST["confirm_password"];


    // 1. Check password match
    if ($password !== $conf_pass) {
        die("Error: Passwords do not match.");
    }

    // 2. Hash password
    $hash_password = password_hash($password, PASSWORD_DEFAULT);
    error_log("Password hashed successfully");

    // 3. Connect to DB
    $con = mysqli_connect("localhost", "root", "", "user_management", 3306);

    if (!$con) {
        die("Database connection failed: " . mysqli_connect_error());
    }
    error_log("Database connected successfully");

    // 4. Check if email already exists
    $checkStmt = mysqli_prepare($con, "SELECT id FROM users WHERE email = ?");
    mysqli_stmt_bind_param($checkStmt, "s", $email);
    mysqli_stmt_execute($checkStmt);
    mysqli_stmt_store_result($checkStmt);

    if (mysqli_stmt_num_rows($checkStmt) > 0) {
        die("Error: Email already exists. Please use another email.");
    }

    // 5. Insert user
    $stmt = mysqli_prepare($con, 
        "INSERT INTO users (first_name, last_name, email, phone, password_hash, role, status) 
         VALUES (?, ?, ?, ?, ?, ?, 'Active')");
    
    if (!$stmt) {
        die("Error preparing statement: " . mysqli_error($con));
    }
    
    mysqli_stmt_bind_param($stmt, "ssssss", $firstName, $lastName, $email, $phone, $hash_password, $role);
    error_log("Attempting to insert user: $firstName $lastName, $email, $role");

    if (!mysqli_stmt_execute($stmt)) {
        die("Error inserting user: " . mysqli_stmt_error($stmt));
    } else {
        error_log("User inserted successfully");
        // Redirect to login page after successful registration
        header("Location: signin.php?registered=success");
        exit;
    }
    
    mysqli_stmt_close($stmt);
    mysqli_close($con);
} else {
    echo "No form data received. Please make sure the form is submitted correctly.";
    echo "<br><a href='signup.php'>Go back to Signup</a>";
}
?>

