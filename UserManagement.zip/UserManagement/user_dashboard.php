<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: signin.php");
    exit;
}

// Check if user is regular user
if ($_SESSION['user_role'] !== 'User') {
    header("Location: signin.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard - BoardBuddy</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f5f5f5;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid #e0e0e0;
        }
        .welcome {
            font-size: 24px;
            color: #333;
        }
        .user-info {
            color: #666;
        }
        .logout-btn {
            background: #dc3545;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
        }
        .dashboard-content {
            text-align: center;
            padding: 50px 0;
        }
        .success-message {
            background: #d4edda;
            color: #155724;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div>
                <div class="welcome">Welcome, <?php echo htmlspecialchars($_SESSION['user_name']); ?>!</div>
                <div class="user-info">User Dashboard</div>
            </div>
            <a href="signin.php" class="logout-btn">Logout</a>
        </div>
        
        <div class="dashboard-content">
            <div class="success-message">
                <h2>🎉 Login Successful!</h2>
                <p>You have successfully logged in as a User.</p>
            </div>
            
            <h3>User Features:</h3>
            <ul style="text-align: left; max-width: 400px; margin: 0 auto;">
                <li>Search Properties</li>
                <li>View Property Details</li>
                <li>Contact Property Owners</li>
                <li>Manage Profile</li>
            </ul>
        </div>
    </div>
</body>
</html>



