<?php
// PHP script to add phone_number column to users table
// Run this script once to add the missing column

// Database connection
$con = mysqli_connect("localhost", "root", "", "user_management", 3306);

if (!$con) {
    die("Database connection failed: " . mysqli_connect_error());
}

echo "Connected to database successfully.<br>";

// Check if phone column already exists
$checkColumnQuery = "SHOW COLUMNS FROM users LIKE 'phone'";
$result = mysqli_query($con, $checkColumnQuery);

if (mysqli_num_rows($result) > 0) {
    echo "Column 'phone' already exists in users table.<br>";
} else {
    // Add phone column
    $alterQuery = "ALTER TABLE users ADD COLUMN phone VARCHAR(20) NULL AFTER email";
    
    if (mysqli_query($con, $alterQuery)) {
        echo "Column 'phone' added successfully to users table.<br>";
        
        // Add index for better performance
        $indexQuery = "CREATE INDEX idx_phone ON users(phone)";
        if (mysqli_query($con, $indexQuery)) {
            echo "Index on phone created successfully.<br>";
        } else {
            echo "Warning: Could not create index on phone: " . mysqli_error($con) . "<br>";
        }
    } else {
        echo "Error adding column: " . mysqli_error($con) . "<br>";
    }
}

// Show table structure
echo "<br>Current table structure:<br>";
$describeQuery = "DESCRIBE users";
$result = mysqli_query($con, $describeQuery);

if ($result) {
    echo "<table border='1'>";
    echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>";
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>" . $row['Field'] . "</td>";
        echo "<td>" . $row['Type'] . "</td>";
        echo "<td>" . $row['Null'] . "</td>";
        echo "<td>" . $row['Key'] . "</td>";
        echo "<td>" . $row['Default'] . "</td>";
        echo "<td>" . $row['Extra'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
}

mysqli_close($con);
echo "<br>Database connection closed.<br>";
echo "<br><strong>You can now delete this file (add_phone_column.php) as it's no longer needed.</strong>";
?>
