<?php
session_start();

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'Admin') {
    header("Location: signin.php");
    exit;
}

// Check if request is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: AdminPanel.php");
    exit;
}

// Get form data
$userId = trim($_POST['userId'] ?? '');
$firstName = trim($_POST['firstName'] ?? '');
$lastName = trim($_POST['lastName'] ?? '');
$email = trim($_POST['email'] ?? '');
$phoneNumber = trim($_POST['phoneNumber'] ?? '');
$role = trim($_POST['role'] ?? '');
$status = trim($_POST['status'] ?? 'Active');
$password = $_POST['password'] ?? '';

// Validation
$errors = [];

if (empty($userId) || !is_numeric($userId)) {
    $errors[] = "Invalid user ID";
}

if (empty($firstName)) {
    $errors[] = "First name is required";
}

if (empty($lastName)) {
    $errors[] = "Last name is required";
}

if (empty($email)) {
    $errors[] = "Email is required";
} elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = "Invalid email format";
}

if (!empty($phoneNumber) && !preg_match('/^[\+]?[0-9\s\-\(\)]{10,}$/', $phoneNumber)) {
    $errors[] = "Invalid phone number format";
}

if (empty($role)) {
    $errors[] = "Role is required";
} elseif (!in_array($role, ['Admin', 'User', 'Owner'])) {
    $errors[] = "Invalid role selected";
}

if (!in_array($status, ['Active', 'Inactive'])) {
    $errors[] = "Invalid status selected";
}

// If there are validation errors, redirect back with errors
if (!empty($errors)) {
    $errorMessage = implode(', ', $errors);
    header("Location: AdminPanel.php?error=" . urlencode($errorMessage));
    exit;
}

// Connect to database
$con = mysqli_connect("localhost", "root", "", "user_management", 3306);
if (!$con) {
    header("Location: AdminPanel.php?error=" . urlencode("Database connection failed"));
    exit;
}

// Check if user exists
$checkUserQuery = "SELECT id FROM users WHERE id = ?";
$checkUserStmt = mysqli_prepare($con, $checkUserQuery);
mysqli_stmt_bind_param($checkUserStmt, "i", $userId);
mysqli_stmt_execute($checkUserStmt);
$checkUserResult = mysqli_stmt_get_result($checkUserStmt);

if (mysqli_num_rows($checkUserResult) == 0) {
    mysqli_close($con);
    header("Location: AdminPanel.php?error=" . urlencode("User not found"));
    exit;
}

// Check if email already exists for another user
$checkEmailQuery = "SELECT id FROM users WHERE email = ? AND id != ?";
$checkEmailStmt = mysqli_prepare($con, $checkEmailQuery);
mysqli_stmt_bind_param($checkEmailStmt, "si", $email, $userId);
mysqli_stmt_execute($checkEmailStmt);
$checkEmailResult = mysqli_stmt_get_result($checkEmailStmt);

if (mysqli_num_rows($checkEmailResult) > 0) {
    mysqli_close($con);
    header("Location: AdminPanel.php?error=" . urlencode("Email already exists for another user"));
    exit;
}

// Prepare update query
if (!empty($password)) {
    // Update with password
    if (strlen($password) < 6) {
        mysqli_close($con);
        header("Location: AdminPanel.php?error=" . urlencode("Password must be at least 6 characters long"));
        exit;
    }
    
    $passwordHash = password_hash($password, PASSWORD_DEFAULT);
    $updateQuery = "UPDATE users SET first_name = ?, last_name = ?, email = ?, phone = ?, password_hash = ?, role = ?, status = ? WHERE id = ?";
    $updateStmt = mysqli_prepare($con, $updateQuery);
    mysqli_stmt_bind_param($updateStmt, "sssssssi", $firstName, $lastName, $email, $phoneNumber, $passwordHash, $role, $status, $userId);
} else {
    // Update without password
    $updateQuery = "UPDATE users SET first_name = ?, last_name = ?, email = ?, phone = ?, role = ?, status = ? WHERE id = ?";
    $updateStmt = mysqli_prepare($con, $updateQuery);
    mysqli_stmt_bind_param($updateStmt, "ssssssi", $firstName, $lastName, $email, $phoneNumber, $role, $status, $userId);
}

if (mysqli_stmt_execute($updateStmt)) {
    mysqli_close($con);
    header("Location: AdminPanel.php?success=" . urlencode("User updated successfully"));
    exit;
} else {
    mysqli_close($con);
    header("Location: AdminPanel.php?error=" . urlencode("Failed to update user"));
    exit;
}
?>
