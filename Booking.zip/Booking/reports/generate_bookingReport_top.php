<?php
session_start();
include '../db.php';
require '../vendor/autoload.php'; // mPDF autoload

use Mpdf\Mpdf;

// ✅ Ensure only admins can generate reports
if (!isset($_SESSION['user_id']) || ($_SESSION['user_role'] ?? '') !== 'Admin') {
    header("Location: ../signin.php");
    exit;
}

// ✅ Fetch top booked properties
$query = "
    SELECT p.title AS property, COUNT(b.id) AS bookings
    FROM bookings b
    JOIN properties p ON b.property_id = p.id
    GROUP BY b.property_id
    ORDER BY bookings DESC
    LIMIT 20
";
$result = $conn->query($query);

$properties = [];
$bookings = [];
$total = 0;
$tableRows = '';

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $properties[] = $row['property'];
        $bookings[] = (int)$row['bookings'];
        $total += $row['bookings'];
    }
}

// ✅ Build table rows
foreach ($properties as $i => $prop) {
    $count = $bookings[$i];
    $percentage = $total > 0 ? round(($count / $total) * 100, 2) : 0;
    $tableRows .= "
        <tr>
            <td style='border:1px solid #ddd; padding:8px;'>$prop</td>
            <td style='border:1px solid #ddd; padding:8px;'>$count</td>
            <td style='border:1px solid #ddd; padding:8px;'>$percentage%</td>
        </tr>
    ";
}

// Total row
$tableRows .= "
    <tr style='font-weight:bold;'>
        <td style='border:1px solid #ddd; padding:8px;'>Total</td>
        <td style='border:1px solid #ddd; padding:8px;'>$total</td>
        <td style='border:1px solid #ddd; padding:8px;'>100%</td>
    </tr>
";

// ✅ Prepare bar chart configuration
$chartConfig = [
    'type' => 'bar',
    'data' => [
        'labels' => $properties,
        'datasets' => [[
            'label' => 'Bookings',
            'data' => $bookings,
            'backgroundColor' => '#2563eb'
        ]]
    ],
    'options' => [
        'plugins' => [
            'legend' => ['display' => false]
        ],
        'scales' => [
            'y' => [
                'beginAtZero' => true,
                'ticks' => ['precision' => 0]
            ],
            'x' => ['ticks' => ['precision' => 0]]
        ]
    ]
];

// ✅ Generate chart URL and fetch base64
$chartUrl = "https://quickchart.io/chart?width=800&height=500&c=" . urlencode(json_encode($chartConfig));
$chartImage = @file_get_contents($chartUrl);
$chartBase64 = $chartImage ? 'data:image/png;base64,' . base64_encode($chartImage) : null;

// ✅ Generate PDF
$mpdf = new Mpdf([
    'allow_output_buffering' => true,
    'isRemoteEnabled' => true
]);
$mpdf->SetTitle('Top Booked Properties Report');

$html = '
<h1 style="text-align:center; color:#333;">Top Booked Properties Report</h1>
<p style="text-align:center; font-size:14px; color:#666;">Generated on: '.date("Y-m-d H:i:s").'</p>
<hr style="margin:15px 0;">

<h3 style="color:#333;">Property Booking Summary</h3>
<table style="width:100%; border-collapse:collapse; margin-bottom:15px; font-size:13px;">
    <tr>
        <th style="border:1px solid #ddd; padding:8px; background:#f0f0f0;">Property</th>
        <th style="border:1px solid #ddd; padding:8px; background:#f0f0f0;">Bookings</th>
        <th style="border:1px solid #ddd; padding:8px; background:#f0f0f0;">Percentage</th>
    </tr>'
    . $tableRows .
'</table>';

// Add chart
if ($chartBase64) {
    $html .= '
    <div style="text-align:center; margin-top:25px;">
        <h3 style="color:#333;">Top Booked Properties</h3>
        <img src="'.$chartBase64.'" style="width:90%; max-width:700px;" />
    </div>';
} else {
    $html .= '<p style="text-align:center; color:red;">⚠️ Could not load chart. Please check your internet connection.</p>';
}

// Output PDF
$mpdf->WriteHTML($html);
$filename = 'Top_Booked_Properties_Report_'.date("Ymd_His").'.pdf';
$mpdf->Output($filename, 'D');
exit;
?>