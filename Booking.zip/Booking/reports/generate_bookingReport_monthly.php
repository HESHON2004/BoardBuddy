<?php
session_start();
include '../db.php';
require '../vendor/autoload.php';
use Mpdf\Mpdf;

// ✅ Ensure only admins can generate reports
if (!isset($_SESSION['user_id']) || ($_SESSION['user_role'] ?? '') !== 'Admin') {
    header("Location: ../signin.php");
    exit;
}

// ✅ Fetch bookings count grouped by month
$query = "
    SELECT DATE_FORMAT(created_at, '%Y-%m') AS month, COUNT(*) AS count
    FROM bookings
    GROUP BY month
    ORDER BY month ASC
";
$result = $conn->query($query);

$months = [];
$counts = [];
$total = 0;

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $months[] = $row['month'];
        $counts[] = (int)$row['count'];
        $total += $row['count'];
    }
}

// ✅ Build table rows
$tableRows = '';
for ($i = 0; $i < count($months); $i++) {
    $percentage = $total > 0 ? round(($counts[$i] / $total) * 100, 2) : 0;
    $tableRows .= "
        <tr>
            <td style='border:1px solid #ddd; padding:8px;'>{$months[$i]}</td>
            <td style='border:1px solid #ddd; padding:8px;'>{$counts[$i]}</td>
            <td style='border:1px solid #ddd; padding:8px;'>{$percentage}%</td>
        </tr>
    ";
}
$tableRows .= "
    <tr style='font-weight:bold;'>
        <td style='border:1px solid #ddd; padding:8px;'>Total</td>
        <td style='border:1px solid #ddd; padding:8px;'>{$total}</td>
        <td style='border:1px solid #ddd; padding:8px;'>100%</td>
    </tr>
";

// ✅ Prepare line chart configuration
$chartConfig = [
    'type' => 'line',
    'data' => [
        'labels' => $months,
        'datasets' => [[
            'label' => 'Bookings',
            'data' => $counts,
            'fill' => false,
            'borderColor' => '#2563eb',
            'backgroundColor' => '#2563eb',
            'tension' => 0.2
        ]]
    ],
    'options' => [
        'plugins' => ['legend' => ['display' => true, 'position' => 'bottom']],
        'scales' => [
            'x' => ['title' => ['display' => true, 'text' => 'Month']],
            'y' => ['title' => ['display' => true, 'text' => 'Count'], 'beginAtZero' => true]
        ]
    ]
];

$chartUrl = "https://quickchart.io/chart?c=" . urlencode(json_encode($chartConfig)) . "&width=700&height=400&format=png";
$chartImage = @file_get_contents($chartUrl);
$chartBase64 = $chartImage ? 'data:image/png;base64,' . base64_encode($chartImage) : null;

// ✅ Create PDF
$mpdf = new Mpdf([
    'allow_output_buffering' => true,
    'isRemoteEnabled' => true
]);
$mpdf->SetTitle('Monthly Booking Trends Report');

// ✅ Build HTML content
$html = '
<h1 style="text-align:center; color:#333;">Monthly Booking Trends Report</h1>
<p style="text-align:center; font-size:14px; color:#666;">Generated on: '.date("Y-m-d H:i:s").'</p>
<hr style="margin:15px 0;">

<h3 style="color:#333;">Summary</h3>
<table style="width:100%; border-collapse:collapse; margin-bottom:15px; font-size:13px;">
    <tr>
        <th style="border:1px solid #ddd; padding:8px; background:#f0f0f0;">Month</th>
        <th style="border:1px solid #ddd; padding:8px; background:#f0f0f0;">Bookings</th>
        <th style="border:1px solid #ddd; padding:8px; background:#f0f0f0;">Percentage</th>
    </tr>
    '.$tableRows.'
</table>
';

// ✅ Add chart
if ($chartBase64) {
    $html .= '
    <div style="text-align:center; margin-top:25px;">
        <h3 style="color:#333;">Bookings Trend Over Time</h3>
        <img src="'.$chartBase64.'" style="width:90%; max-width:700px;" />
    </div>';
} else {
    $html .= '<p style="text-align:center; color:red;">⚠️ Could not load chart. Please check your internet connection.</p>';
}

// ✅ Output PDF
$mpdf->WriteHTML($html);
$filename = 'Monthly_Booking_Trends_Report_'.date("Ymd_His").'.pdf';
$mpdf->Output($filename, 'D');
exit;
?>