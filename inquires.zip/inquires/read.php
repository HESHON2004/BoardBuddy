<?php
include "db.php";
header('Content-Type: application/json');

$result = $conn->query("SELECT * FROM inquiries ORDER BY id DESC");

$inquiries = [];
while ($row = $result->fetch_assoc()) {
    $inquiries[] = $row;
}

echo json_encode($inquiries);
?>
