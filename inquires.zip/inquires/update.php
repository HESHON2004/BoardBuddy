<?php
include "db.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id      = $_POST['id'];
    $name    = $_POST['name'];
    $email   = $_POST['email'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];
    $status  = $_POST['status'];

    $file = "";
    if (!empty($_FILES['file']['name'])) {
        $file = time() . "_" . basename($_FILES['file']['name']);
        move_uploaded_file($_FILES['file']['tmp_name'], "../uploads/" . $file);
    } else {
        $file = $_POST['existingFile'];
    }

    $sql = "UPDATE inquiries SET 
                name='$name',
                email='$email',
                subject='$subject',
                message='$message',
                file='$file',
                status='$status'
            WHERE id=$id";

    if ($conn->query($sql)) {
        echo json_encode(["success" => true]);
    } else {
        echo json_encode(["success" => false, "error" => $conn->error]);
    }
}
?>
