<?php
$host = "localhost";
$user = "root"; // default WAMP username
$pass = "";     // default WAMP password is empty
$db   = "boardbuddy";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}
?>
