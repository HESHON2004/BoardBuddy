<?php
include "db.php";
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name    = $conn->real_escape_string($_POST['name'] ?? '');
    $email   = $conn->real_escape_string($_POST['email'] ?? '');
    $subject = $conn->real_escape_string($_POST['subject'] ?? '');
    $message = $conn->real_escape_string($_POST['message'] ?? '');
    $status  = "Pending";
    $date    = date("Y-m-d");

    $file = "";
    if (isset($_FILES['file']) && $_FILES['file']['error'] === 0) {
        $file = time() . "_" . basename($_FILES['file']['name']);
        $uploadPath = __DIR__ . "/../uploads/" . $file;
        if (!is_dir(__DIR__ . "/../uploads")) {
            mkdir(__DIR__ . "/../uploads", 0777, true);
        }
        move_uploaded_file($_FILES['file']['tmp_name'], $uploadPath);
    }

    $sql = "INSERT INTO inquiries (name,email,subject,message,file,date,status) 
            VALUES ('$name','$email','$subject','$message','$file','$date','$status')";

    if ($conn->query($sql)) {
        echo "✅ Insert Success";
    } else {
        echo "❌ Insert Failed: " . $conn->error;
    }
}
